#!/usr/bin/env node
// Dirronlive TikTok connector.
//
// Dirronlive запускает этот процесс при нажатии «Подключиться» и завершает
// при «Отключиться». Связь — строки JSON в stdout:
//   {"type":"status","status":"connecting"|"connected"|"offline"|"error"|"ended"|"disconnected", ...}
//   {"type":"gift", ...поля normalizeGift...}
// Если Dirronlive закрылся (stdin закрыт) или прислал "stop", процесс выходит.
//
// --fetch-gifts [--user ник] [--lang ru-RU]: один ответ {"type":"gifts","gifts":[{id,name,diamonds,image}]}
// и выход. Сначала общий список TikTok (webcast/gift/list: все подарки региона,
// эфир не нужен), если он недоступен — каталог эфира ника (fetchAvailableGifts).
//
// Используется библиотека tiktok-live-connector (Node.js, AGPL-3.0):
// https://github.com/zerodytrash/TikTok-Live-Connector
import {
  classifyError, normalizeCatalog, normalizeChat, normalizeFollow, normalizeGift, normalizeLike, normalizeRoom,
  parseArgs, parsePublicGiftList, publicGiftListUrl, toJsonLine,
} from './lib.mjs';

const args = parseArgs(process.argv.slice(2));
const emit = (object) => process.stdout.write(toJsonLine(object) + '\n');

let lib;
try {
  lib = await import(process.env.DIRRONLIVE_TIKTOK_LIB || 'tiktok-live-connector');
} catch (error) {
  emit({ type: 'status', status: 'error', kind: 'service',
    message: `Не найдена библиотека tiktok-live-connector: ${error.message}` });
  process.exit(3);
}

const { TikTokLiveConnection, WebcastEvent, ControlEvent, SignConfig } = lib;

if (args.selfCheck) {
  const missing = [];
  if (typeof TikTokLiveConnection !== 'function') missing.push('TikTokLiveConnection');
  if (!WebcastEvent?.GIFT) missing.push('WebcastEvent.GIFT');
  if (!WebcastEvent?.STREAM_END) missing.push('WebcastEvent.STREAM_END');
  if (!ControlEvent?.CONNECTED) missing.push('ControlEvent.CONNECTED');
  if (!ControlEvent?.DISCONNECTED) missing.push('ControlEvent.DISCONNECTED');
  if (typeof lib.UserOfflineError !== 'function') missing.push('UserOfflineError');
  // Каталог подарков нужен только для сверки — его отсутствие не ломает эфир.
  const catalog = typeof TikTokLiveConnection?.prototype?.fetchAvailableGifts === 'function';
  emit({ type: 'selfcheck', ok: missing.length === 0, missing, catalog, version: lib.VERSION ?? null,
    node: process.version });
  process.exit(missing.length === 0 ? 0 : 4);
}

/** Полный список подарков TikTok без эфира (см. publicGiftListUrl). */
async function fetchPublicGifts() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    // DIRRONLIVE_GIFT_LIST_URL — только для проверок (подменный ответ).
    const res = await fetch(process.env.DIRRONLIVE_GIFT_LIST_URL || publicGiftListUrl(args.lang), {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
          + 'Chrome/131.0.0.0 Safari/537.36',
        Accept: 'application/json, text/plain, */*',
        'Accept-Language': args.lang,
        Referer: 'https://www.tiktok.com/',
      },
    });
    if (!res.ok) throw new Error(`TikTok ответил HTTP ${res.status}`);
    return { gifts: parsePublicGiftList(await res.json()), how: 'webcast/gift/list' };
  } finally {
    clearTimeout(timer);
  }
}

if (args.fetchGifts) {
  // Общий список — без ника и без эфира.
  try {
    const result = await fetchPublicGifts();
    emit({ type: 'gifts', uniqueId: args.user, source: 'public', how: result.how, gifts: result.gifts });
    setTimeout(() => process.exit(0), 100);
    await new Promise(() => {});
  } catch (error) {
    args.publicError = `webcast/gift/list: ${error?.name === 'AbortError' ? 'нет ответа 20 с' : (error?.message ?? error)}`;
    if (!args.user) {
      const e = new Error(args.publicError);
      emit({ type: 'status', ...classifyError(e), attempts: [args.publicError] });
      setTimeout(() => process.exit(1), 100);
      await new Promise(() => {});
    }
  }
}

if (!args.user) {
  emit({ type: 'status', status: 'error', kind: 'service', message: 'Не указан ник TikTok.' });
  process.exit(2);
}

if (args.key && SignConfig) SignConfig.apiKey = args.key;

/**
 * Каталог подарков эфира. Пробует по очереди: штатный fetchAvailableGifts(),
 * кэш availableGifts после подключения, маршрут TikTok fetchRoomGifts по
 * roomId. Возвращает { gifts, how } или бросает ошибку со всеми попытками.
 */
async function fetchGiftsVia(conn) {
  const attempts = [];
  const tryList = async (how, call) => {
    try {
      const raw = await call();
      const gifts = normalizeCatalog(raw);
      if (gifts.length) return { gifts, how };
      attempts.push(`${how}: пустой ответ`);
    } catch (error) {
      attempts.push(`${how}: ${error?.message ?? error}`);
    }
    return null;
  };
  if (typeof conn.fetchAvailableGifts === 'function') {
    const r = await tryList('fetchAvailableGifts', () => conn.fetchAvailableGifts());
    if (r) return r;
  } else {
    attempts.push('fetchAvailableGifts: нет в этой версии библиотеки');
  }
  const cached = normalizeCatalog(conn.availableGifts);
  if (cached.length) return { gifts: cached, how: 'availableGifts' };
  const routes = lib.RouteConfig;
  const roomId = conn.roomId ?? conn.state?.roomId ?? conn.roomInfo?.id_str ?? conn.roomInfo?.id;
  if (typeof routes?.fetchRoomGifts === 'function') {
    const r = await tryList('fetchRoomGifts', () => routes.fetchRoomGifts({ webClient: conn.webClient, roomId }));
    if (r) return r;
  }
  if (typeof routes?.fetchRoomGiftsFromProvider === 'function') {
    const r = await tryList('fetchRoomGiftsFromProvider',
      () => routes.fetchRoomGiftsFromProvider({ apiClient: conn.webClient?.apiClient ?? conn.apiClient, roomId }));
    if (r) return r;
  }
  const error = new Error(attempts.join('; ') || 'нет способа получить каталог');
  error.attempts = attempts;
  throw error;
}

function giftsError(error, where) {
  const c = classifyError(error);
  return { type: 'giftsError', where, kind: c.kind, status: c.status,
    message: `${c.message}`.trim(), attempts: error?.attempts ?? [] };
}

if (args.fetchGifts) {
  const catalogConnection = new TikTokLiveConnection(args.user, { signApiKey: args.key || undefined,
    processInitialData: false, enableExtendedGiftInfo: false });
  let result = null;
  let firstError = null;
  try {
    result = await fetchGiftsVia(catalogConnection);
  } catch (error) {
    firstError = error;
  }
  if (!result) {
    // Без подключения TikTok часто не отдаёт список: подключаемся к эфиру,
    // берём каталог этой комнаты и сразу отключаемся.
    try {
      await catalogConnection.connect();
      result = await fetchGiftsVia(catalogConnection);
    } catch (error) {
      const attempts = [...(args.publicError ? [args.publicError] : []), ...(firstError?.attempts ?? []),
        ...(error?.attempts ?? [`connect: ${error?.message ?? error}`])];
      error.attempts = attempts;
      emit({ type: 'status', ...classifyError(error), attempts });
      try { catalogConnection.disconnect?.(); } catch { /* уже */ }
      setTimeout(() => process.exit(1), 100);
    }
    try { catalogConnection.disconnect?.(); } catch { /* уже */ }
  }
  if (result) {
    emit({ type: 'gifts', uniqueId: args.user, how: result.how, gifts: result.gifts });
    setTimeout(() => process.exit(0), 100);
  }
  await new Promise(() => {}); // ждём выхода
}

let finished = false;
function finish(code) {
  if (finished) return;
  finished = true;
  try { connection?.disconnect?.(); } catch { /* уже отключено */ }
  setTimeout(() => process.exit(code), 150);
}

// Dirronlive закрылся или попросил остановиться.
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => { if (String(chunk).includes('stop')) finish(0); });
process.stdin.on('end', () => finish(0));
process.on('SIGTERM', () => finish(0));

emit({ type: 'status', status: 'connecting', uniqueId: args.user });

const connection = new TikTokLiveConnection(args.user, {
  signApiKey: args.key || undefined,
  // Без старых сообщений из начального пакета — иначе после переподключения
  // прошлые подарки пришли бы повторно.
  processInitialData: false,
  enableExtendedGiftInfo: false,
});

let connected = false;
let giftsBusy = false;

// Каталог подарков из текущего подключения к эфиру: сразу после подключения
// и по запросу Dirronlive («Обновить каталог» — строка "gifts" в stdin).
process.stdin.on('data', (chunk) => {
  if (String(chunk).includes('gifts') && connected) void sendGifts('request');
});
async function sendGifts(where) {
  if (giftsBusy) return;
  giftsBusy = true;
  try {
    // Полный список TikTok, если недоступен — каталог этой комнаты.
    let result;
    try {
      result = await fetchPublicGifts();
    } catch (publicError) {
      try {
        result = await fetchGiftsVia(connection);
      } catch (error) {
        error.attempts = [`webcast/gift/list: ${publicError?.message ?? publicError}`, ...(error.attempts ?? [])];
        throw error;
      }
    }
    emit({ type: 'gifts', uniqueId: args.user, source: 'live', where, how: result.how, gifts: result.gifts });
  } catch (error) {
    emit(giftsError(error, where));
  } finally {
    giftsBusy = false;
  }
}

connection.on(WebcastEvent.GIFT, (data) => {
  try {
    emit(normalizeGift(data));
  } catch (error) {
    emit({ type: 'log', level: 'warn', message: `Не удалось разобрать подарок: ${error.message}` });
  }
});

// Лайки, подписки и чат — для оверлеев (рейтинги, цели, голосование).
function relay(eventName, normalize) {
  if (!eventName) return;
  connection.on(eventName, (data) => {
    try {
      const out = normalize(data);
      if (out) emit(out);
    } catch (error) {
      emit({ type: 'log', level: 'warn', message: `Событие ${eventName}: ${error.message}` });
    }
  });
}
relay(WebcastEvent.LIKE, normalizeLike);
relay(WebcastEvent.FOLLOW, normalizeFollow);
relay(WebcastEvent.CHAT, normalizeChat);

connection.on(WebcastEvent.STREAM_END, (event) => {
  emit({ type: 'status', status: 'ended', action: String(event?.action ?? ''),
    message: 'Эфир завершён.' });
  finish(0);
});

connection.on(ControlEvent.DISCONNECTED, (event) => {
  if (finished) return;
  emit({ type: 'status', status: 'disconnected', code: event?.code ?? null,
    message: `Соединение с эфиром прервалось${event?.reason ? `: ${event.reason}` : ''}.` });
  finish(0);
});

connection.on(ControlEvent.ERROR, (event) => {
  const error = event?.exception ?? event;
  emit({ type: 'log', level: 'error', message: String(error?.message ?? event?.info ?? error) });
});

try {
  const state = await connection.connect();
  connected = true;
  emit({ type: 'status', status: 'connected', uniqueId: args.user,
    roomId: state?.roomId ? String(state.roomId) : null });
  try {
    emit(normalizeRoom(state?.roomInfo, state?.roomId));
  } catch (error) {
    emit({ type: 'log', level: 'warn', message: `Сведения об эфире: ${error.message}` });
  }
  void sendGifts('connect');
} catch (error) {
  if (!connected) {
    const result = classifyError(error);
    emit({ type: 'status', ...result });
    finish(result.status === 'offline' ? 0 : 1);
  }
}
