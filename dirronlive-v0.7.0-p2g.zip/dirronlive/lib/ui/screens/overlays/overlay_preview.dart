import 'dart:async';

import 'package:flutter/material.dart';

import '../../theme/app_colors.dart';
import '../parkour/action_look.dart';

/// Предпросмотр оверлея в программе: та же модель, что у страницы для
/// TikTok LIVE Studio, нарисованная виджетами. Макет — 540 px в ширину
/// (половина вертикального холста 1080×1920), дальше масштабируется.
class OverlayPreview extends StatefulWidget {
  const OverlayPreview({super.key, required this.model, this.width = 540});

  final Map<String, Object?> model;
  final double width;

  @override
  State<OverlayPreview> createState() => _OverlayPreviewState();
}

class _OverlayPreviewState extends State<OverlayPreview> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    if (widget.model['kind'] == 'timer' || widget.model['countdownEndMs'] != null) {
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() {});
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // Размеры как в CSS страницы: 1vw = ширина / 100.
  double get vw => widget.width / 100;

  Color _color(Object? hex, Color fallback) {
    if (hex is! String || !hex.startsWith('#') || hex.length != 7) return fallback;
    return Color(int.parse('FF${hex.substring(1)}', radix: 16));
  }

  TextStyle _t(double size, {FontWeight w = FontWeight.w800, Color c = AppColors.text}) =>
      TextStyle(fontSize: size * vw, fontWeight: w, color: c, height: 1.15, shadows: const [
        Shadow(color: Color(0x8C000000), blurRadius: 6, offset: Offset(0, 2)),
      ]);

  @override
  Widget build(BuildContext context) {
    final m = widget.model;
    final style = m['style'] is Map ? (m['style']! as Map).cast<String, Object?>() : const <String, Object?>{};
    final frame = '${style['frame'] ?? 'card'}';
    final scale = ((style['scale'] is num ? (style['scale']! as num).toDouble() : 100) / 100).clamp(0.5, 2.0);
    final bg = ((style['bg'] is num ? (style['bg']! as num).toDouble() : 86) / 100).clamp(0.0, 1.0);
    final accent = _color(style['accent'], const Color(0xFFA78BFA));
    final showTitle = style['showTitle'] != false;
    final align = '${style['align'] ?? 'left'}';
    final cross = switch (align) {
      'center' => CrossAxisAlignment.center,
      'right' => CrossAxisAlignment.end,
      _ => CrossAxisAlignment.start,
    };
    final card = Container(
      key: const Key('overlay-preview-card'),
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: frame == 'none' ? 0 : 3.6 * vw, vertical: 3 * vw),
      decoration: BoxDecoration(
        color: frame == 'none' ? null : const Color(0xFF251634).withAlpha((bg * 255).round()),
        borderRadius: BorderRadius.circular(3.2 * vw),
        border: frame == 'card' ? Border.all(color: accent, width: 0.35 * vw) : null,
        boxShadow: frame == 'card'
            ? const [BoxShadow(color: Color(0x73000000), blurRadius: 24, offset: Offset(0, 8))]
            : null,
      ),
      child: Column(
        crossAxisAlignment: cross,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (showTitle) ...[
            Text('${m['title'] ?? ''}'.toUpperCase(), style: _t(4.4, w: FontWeight.w900, c: accent)),
            SizedBox(height: 1.6 * vw),
          ],
          _body(m),
        ],
      ),
    );
    return SizedBox(
      width: widget.width,
      child: Padding(
        padding: EdgeInsets.all(2.2 * vw),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            // Размер: как CSS zoom на странице — карточка крупнее или мельче.
            Transform.scale(scale: scale, alignment: Alignment.topLeft, child: card),
            if (m['test'] == true)
              Positioned(
                top: -1 * vw,
                right: 1 * vw,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 1.6 * vw, vertical: 0.4 * vw),
                  decoration: BoxDecoration(color: AppColors.warning, borderRadius: BorderRadius.circular(2 * vw)),
                  child: Text('ТЕСТ', style: TextStyle(fontSize: 2.6 * vw, fontWeight: FontWeight.w900, color: AppColors.onAccent)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _icon(Object? url, {bool big = false}) {
    final size = (big ? 18 : 8) * vw;
    return GiftAvatar(imageUrl: url is String ? url : null, size: size);
  }

  /// Аватарка зрителя; без картинки или при ошибке — первая буква ника.
  Widget _avatar(Object? url, String name) {
    final size = 8.5 * vw;
    final trimmed = name.trim();
    final letter = trimmed.isEmpty ? '?' : String.fromCharCode(trimmed.runes.first).toUpperCase();
    var h = 0;
    for (final r in name.runes) {
      h = (h * 31 + r) % 360;
    }
    final fallback = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: HSLColor.fromAHSL(1, h.toDouble(), 0.7, 0.45).toColor(),
        border: Border.all(color: const Color(0xD9FFFFFF), width: 0.45 * vw),
      ),
      child: Text(letter, style: TextStyle(fontSize: 4.2 * vw, fontWeight: FontWeight.w900, color: Colors.white)),
    );
    if (url is! String || !url.startsWith('http')) return fallback;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xD9FFFFFF), width: 0.45 * vw),
      ),
      child: ClipOval(
        child: Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback),
      ),
    );
  }

  Widget _bar(double fraction, {Color? color}) => Container(
        height: 4.4 * vw,
        margin: EdgeInsets.only(top: 2 * vw),
        decoration: BoxDecoration(color: const Color(0x1FFFFFFF), borderRadius: BorderRadius.circular(3 * vw)),
        alignment: Alignment.centerLeft,
        child: FractionallySizedBox(
          widthFactor: fraction.clamp(0.0, 1.0).toDouble(),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(3 * vw),
              color: color,
              gradient: color == null ? AppColors.brandGradient : null,
            ),
          ),
        ),
      );

  Widget _body(Map<String, Object?> m) {
    switch (m['kind']) {
      case 'list':
        final items = (m['items'] as List?)?.cast<Map<String, Object?>>() ?? const [];
        if (items.isEmpty) return Text('${m['empty'] ?? ''}', style: _t(4.4, w: FontWeight.w600, c: AppColors.textMuted));
        return Column(
          children: [
            for (final it in items)
              Padding(
                padding: EdgeInsets.symmetric(vertical: 1.1 * vw),
                child: Row(
                  children: [
                    if (it['rank'] != null)
                      Container(
                        width: 6 * vw,
                        height: 6 * vw,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: switch (it['rank']) {
                            1 => AppColors.warning,
                            2 => const Color(0xFFE6E6F0),
                            3 => const Color(0xFFF0A36B),
                            _ => AppColors.accent,
                          },
                        ),
                        child: Text('${it['rank']}',
                            style: TextStyle(fontSize: 3.6 * vw, fontWeight: FontWeight.w900, color: AppColors.onAccent)),
                      )
                    else
                      _icon(it['icon']),
                    if (it['rank'] != null) ...[
                      SizedBox(width: 2.4 * vw),
                      _avatar(it['avatar'], '${it['name'] ?? ''}'),
                    ],
                    SizedBox(width: 2.4 * vw),
                    Expanded(
                      child: Text('${it['name']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: _t(4.6)),
                    ),
                    Text('${it['value']}',
                        style: _t(4.2, w: FontWeight.w900, c: _color(it['color'], AppColors.success))),
                  ],
                ),
              ),
          ],
        );
      case 'hero':
        final hasIcon = m.containsKey('icon');
        final end = m['countdownEndMs'];
        final left = end is num ? ((end - DateTime.now().millisecondsSinceEpoch) / 1000).ceil() : 0;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (hasIcon) ...[_icon(m['icon'], big: true), SizedBox(width: 3.4 * vw)],
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${m['main']}', style: _t(7.2, w: FontWeight.w900)),
                      if ('${m['sub'] ?? ''}'.isNotEmpty)
                        Padding(
                          padding: EdgeInsets.only(top: vw),
                          child: Text('${m['sub']}', style: _t(4.6, w: FontWeight.w700, c: _color(m['accent'], AppColors.textMuted))),
                        ),
                      if (left > 0) Text('Через $left с', style: _t(4.6, w: FontWeight.w700, c: AppColors.warning)),
                    ],
                  ),
                ),
              ],
            ),
            if (m['progress'] is num) _bar((m['progress']! as num).toDouble()),
          ],
        );
      case 'goal':
        final current = (m['current'] as num?)?.toInt() ?? 0;
        final target = (m['target'] as num?)?.toInt() ?? 1;
        final done = m['done'] == true;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (m['icon'] != null) ...[_icon(m['icon']), SizedBox(width: 2 * vw)],
                Text('$current', style: _t(9, w: FontWeight.w900)),
                SizedBox(width: 2 * vw),
                Text('из $target', style: _t(4.6, w: FontWeight.w700, c: AppColors.textMuted)),
              ],
            ),
            _bar(target > 0 ? current / target : 0, color: done ? AppColors.success : null),
            SizedBox(height: vw),
            Text('${m['label']}', style: _t(4.6, w: FontWeight.w700, c: done ? AppColors.success : AppColors.textMuted)),
          ],
        );
      case 'timer':
        final since = m['startedAtMs'];
        final text = since is num ? _clock(DateTime.now().millisecondsSinceEpoch - since.toInt()) : '--:--';
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(text, style: _t(13, w: FontWeight.w900)),
            if ('${m['note'] ?? ''}'.isNotEmpty) Text('${m['note']}', style: _t(4.6, w: FontWeight.w700, c: AppColors.textMuted)),
          ],
        );
      case 'battle':
        final l = (m['left'] as Map).cast<String, Object?>();
        final r = (m['right'] as Map).cast<String, Object?>();
        final ls = (l['score'] as num).toInt(), rs = (r['score'] as num).toInt();
        final total = ls + rs;
        Widget side(Map<String, Object?> s) => Expanded(
              child: Column(
                children: [
                  _icon(s['icon']),
                  Text('${s['name']}', style: _t(4.4, c: _color(s['color'], AppColors.text))),
                  Text('${s['gift']}', style: _t(4, w: FontWeight.w600, c: AppColors.textMuted)),
                  Text('${s['score']}', style: _t(12, w: FontWeight.w900)),
                ],
              ),
            );
        return Column(
          children: [
            Row(children: [side(l), Text('VS', style: _t(6, w: FontWeight.w900, c: AppColors.warning)), side(r)]),
            Container(
              height: 4.8 * vw,
              margin: EdgeInsets.only(top: 2.4 * vw),
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(3 * vw)),
              child: Row(
                children: [
                  if (total == 0 || ls > 0)
                    Expanded(flex: total == 0 ? 1 : ls, child: Container(color: _color(l['color'], AppColors.danger))),
                  if (total == 0 || rs > 0)
                    Expanded(flex: total == 0 ? 1 : rs, child: Container(color: _color(r['color'], AppColors.accent))),
                ],
              ),
            ),
            SizedBox(height: 1.6 * vw),
            Text('${m['status']}', style: _t(4, c: AppColors.warning)),
          ],
        );
      case 'sky':
        final effects = m['effects'] is List ? (m['effects']! as List) : const [];
        final errors = (m['errors'] as num?)?.toInt() ?? 0;
        final queued = (m['queued'] as num?)?.toInt() ?? 0;
        final notice = '${m['notice'] ?? ''}';
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${m['main']}', style: _t(7.2, w: FontWeight.w900)),
            if ('${m['sub'] ?? ''}'.isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: vw),
                child: Text('${m['sub']}', style: _t(4.6, w: FontWeight.w700, c: AppColors.textMuted)),
              ),
            _bar(m['progress'] is num ? (m['progress']! as num).toDouble() : 0),
            SizedBox(height: 1.6 * vw),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text('${m['time'] ?? ''}',
                      softWrap: false, overflow: TextOverflow.fade, style: _t(8, w: FontWeight.w900)),
                ),
                SizedBox(width: 2 * vw),
                Flexible(
                  child: Text('ошибок $errors',
                      softWrap: false,
                      overflow: TextOverflow.fade,
                      style: _t(5, w: FontWeight.w900, c: errors == 0 ? AppColors.success : AppColors.danger)),
                ),
              ],
            ),
            if (effects.isNotEmpty || queued > 0) ...[
              SizedBox(height: 1.6 * vw),
              Wrap(
                spacing: 1.2 * vw,
                runSpacing: 1.2 * vw,
                children: [
                  for (final e in effects)
                    if (e is Map)
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 1.6 * vw, vertical: 0.5 * vw),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(2 * vw),
                          border: Border.all(color: _color(e['color'], AppColors.accent), width: 0.3 * vw),
                        ),
                        child: Text('${e['title']} · ${e['seconds']} с',
                            style: _t(3.4, c: _color(e['color'], AppColors.accent))),
                      ),
                  if (queued > 0) Text('в очереди $queued', style: _t(3.4, c: AppColors.textMuted)),
                ],
              ),
            ],
            if (notice.isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: 1.6 * vw),
                child: Text(notice, style: _t(4.2, c: AppColors.accentAlt)),
              ),
          ],
        );
      case 'vote':
        final options = (m['options'] as List?)?.cast<Map<String, Object?>>() ?? const [];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final o in options) ...[
              SizedBox(height: 2 * vw),
              Row(
                children: [
                  Container(
                    width: 6.4 * vw,
                    height: 6.4 * vw,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: AppColors.accent, borderRadius: BorderRadius.circular(1.6 * vw)),
                    child: Text('${o['key']}',
                        style: TextStyle(fontSize: 4 * vw, fontWeight: FontWeight.w900, color: AppColors.onAccent)),
                  ),
                  SizedBox(width: 1.6 * vw),
                  Expanded(child: Text('${o['label']}', style: _t(4.8))),
                  Text('${o['percent']}%', style: _t(4.8)),
                ],
              ),
              _bar(((o['percent'] as num?) ?? 0) / 100),
            ],
            SizedBox(height: 1.6 * vw),
            Text('${m['status']} · голосов: ${m['total']}', style: _t(4, c: AppColors.warning)),
          ],
        );
    }
    return const SizedBox.shrink();
  }

  static String _clock(int ms) {
    final s = ms < 0 ? 0 : ms ~/ 1000;
    final h = s ~/ 3600, m = (s % 3600) ~/ 60, r = s % 60;
    String two(int v) => v.toString().padLeft(2, '0');
    return h > 0 ? '$h:${two(m)}:${two(r)}' : '${two(m)}:${two(r)}';
  }
}
