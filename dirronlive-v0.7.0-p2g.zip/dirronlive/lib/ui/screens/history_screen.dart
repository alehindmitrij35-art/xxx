import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/gift_event.dart';
import '../../core/format.dart';
import '../../features/events/event_log.dart';
import '../theme/app_colors.dart';
import '../widgets/common.dart';

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  static const _horizontal = 32.0;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final events = ref.watch(eventLogProvider).events;

    // Вся страница прокручивается целиком, а строки строятся лениво —
    // это работает и при маленьком окне, и при тысячах событий.
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(_horizontal, 28, _horizontal, 20),
          sliver: SliverToBoxAdapter(
            child: PageHeader(
              title: 'История',
              subtitle: 'Полный журнал подарков со статусами доставки и '
                  'действиями в игре, новые сверху. Всего: ${events.length}',
            ),
          ),
        ),
        if (events.isEmpty)
          const SliverPadding(
            padding: EdgeInsets.fromLTRB(_horizontal, 0, _horizontal, 32),
            sliver: SliverToBoxAdapter(child: _EmptyHistory()),
          )
        else ...[
          const SliverPadding(
            padding: EdgeInsets.symmetric(horizontal: _horizontal),
            sliver: SliverToBoxAdapter(child: HistoryHeaderRow()),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(_horizontal, 0, _horizontal, 32),
            sliver: SliverList.builder(
              itemCount: events.length,
              itemBuilder: (context, index) => HistoryRow(
                key: ValueKey('history-${events[index].id}'),
                event: events[index],
                index: index,
                isLast: index == events.length - 1,
              ),
            ),
          ),
        ],
      ],
    );
  }
}

const _flexTime = 4;
const _flexSource = 2;
const _flexViewer = 3;
const _flexGift = 3;
const _flexCount = 2;
const _flexDelivery = 4;
const _flexAction = 5;

class HistoryHeaderRow extends StatelessWidget {
  const HistoryHeaderRow({super.key});

  @override
  Widget build(BuildContext context) {
    const style = TextStyle(
      fontSize: 13,
      fontWeight: FontWeight.w700,
      color: AppColors.textMuted,
    );
    Widget cell(String text, int flex, {TextAlign align = TextAlign.left}) =>
        Expanded(
          flex: flex,
          child: Text(
            text,
            textAlign: align,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: style,
          ),
        );

    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
      child: Container(
        color: AppColors.surfaceHigh,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        child: Row(
          children: [
            cell('Время', _flexTime),
            cell('Источник', _flexSource),
            cell('Зритель', _flexViewer),
            cell('Подарок', _flexGift),
            cell('Количество', _flexCount, align: TextAlign.right),
            const SizedBox(width: 16),
            cell('Доставка', _flexDelivery),
            const SizedBox(width: 12),
            cell('Действие в игре', _flexAction),
          ],
        ),
      ),
    );
  }
}

class HistoryRow extends StatelessWidget {
  const HistoryRow({
    super.key,
    required this.event,
    required this.index,
    required this.isLast,
  });

  final GiftEvent event;
  final int index;
  final bool isLast;

  @override
  Widget build(BuildContext context) {
    const valueStyle = TextStyle(fontSize: 14, color: AppColors.text);
    Widget cell(Widget child, int flex) => Expanded(flex: flex, child: child);
    Text text(String value, {TextAlign align = TextAlign.left, TextStyle? style}) =>
        Text(
          value,
          textAlign: align,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: style ?? valueStyle,
        );

    return ClipRRect(
      borderRadius: isLast
          ? const BorderRadius.vertical(bottom: Radius.circular(14))
          : BorderRadius.zero,
      child: Container(
        color: index.isEven ? AppColors.surface : AppColors.surfaceAlt,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
        child: Row(
          children: [
            cell(
              text(
                formatDateTime(event.createdAt),
                style: const TextStyle(
                  fontSize: 14,
                  color: AppColors.textMuted,
                  fontFeatures: [FontFeature.tabularFigures()],
                ),
              ),
              _flexTime,
            ),
            cell(
              Align(
                alignment: Alignment.centerLeft,
                child: SourceChip(source: event.source),
              ),
              _flexSource,
            ),
            cell(text(event.viewerName), _flexViewer),
            cell(
              text(
                event.giftName,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: AppColors.accentAlt,
                ),
              ),
              _flexGift,
            ),
            cell(
              text(
                event.isCombo ? '×${event.count} комбо' : '×${event.count}',
                align: TextAlign.right,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColors.text,
                ),
              ),
              _flexCount,
            ),
            const SizedBox(width: 16),
            cell(
              Align(
                alignment: Alignment.centerLeft,
                child: DeliveryChip(
                  key: ValueKey('history-delivery-${event.id}'),
                  status: event.delivery,
                  label: event.deliveryLabel,
                ),
              ),
              _flexDelivery,
            ),
            const SizedBox(width: 12),
            cell(
              Tooltip(
                message: event.actionText ?? '',
                child: Text(
                  event.actionText ?? '—',
                  key: ValueKey('history-action-${event.id}'),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: _actionColor(event),
                  ),
                ),
              ),
              _flexAction,
            ),
          ],
        ),
      ),
    );
  }

  static Color _actionColor(GiftEvent event) => switch (event.actionState) {
        ActionState.done => AppColors.success,
        ActionState.pending => AppColors.warning,
        ActionState.failed => AppColors.danger,
        ActionState.skipped => AppColors.textMuted,
        ActionState.none => event.unknownGift ? AppColors.warning : AppColors.textFaint,
      };
}

class _EmptyHistory extends StatelessWidget {
  const _EmptyHistory();

  @override
  Widget build(BuildContext context) {
    return const Panel(
      key: Key('history-empty'),
      padding: EdgeInsets.symmetric(vertical: 36, horizontal: 20),
      child: Center(
        child: Column(
          children: [
            Icon(Icons.inbox_rounded, color: AppColors.accent, size: 36),
            SizedBox(height: 10),
            Text(
              'История пока пуста. Нажми «Тестовый подарок» на вкладке «Эфир».',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 15, color: AppColors.textMuted),
            ),
          ],
        ),
      ),
    );
  }
}
