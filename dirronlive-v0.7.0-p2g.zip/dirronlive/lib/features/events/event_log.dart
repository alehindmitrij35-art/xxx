import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/events/delivery_status.dart';
import '../../core/events/gift_event.dart';
import '../../core/providers.dart';
import '../../core/storage/storage_exception.dart';
import 'event_history_repository.dart';

/// Состояние журнала: один источник данных для экрана «Эфир» и истории.
class EventLogState {
  const EventLogState({required this.events, this.saveError});

  /// Все события, новые сверху.
  final List<GiftEvent> events;

  /// Текст последней ошибки записи на диск или `null`, если всё сохранено.
  final String? saveError;

  GiftEvent? byId(String id) {
    for (final event in events) {
      if (event.id == id) return event;
    }
    return null;
  }

  GiftEvent? byComboId(String comboId) {
    for (final event in events) {
      if (event.comboId == comboId) return event;
    }
    return null;
  }

  /// Запись журнала, в которую попало событие из шины: для шага комбо —
  /// общая запись серии, для одиночного подарка — запись с тем же id.
  GiftEvent? recordFor(GiftEvent step) {
    final comboId = step.comboId;
    if (comboId != null) return byComboId(comboId);
    return byId(step.id);
  }
}

final eventHistoryRepositoryProvider = Provider<EventHistoryRepository>(
  (ref) => EventHistoryRepository(ref.watch(jsonStoreProvider)),
);

final eventLogProvider =
    NotifierProvider<EventLogController, EventLogState>(EventLogController.new);

/// Журнал событий. Подписан на [EventBus]: каждое опубликованное событие
/// попадает в журнал ровно один раз и сразу сохраняется на диск.
/// Статус доставки меняется в той же записи через [setDelivery].
class EventLogController extends Notifier<EventLogState> {
  Future<void> _pendingWrite = Future<void>.value();
  bool _disposed = false;

  @override
  EventLogState build() {
    final bus = ref.watch(eventBusProvider);
    final subscription = bus.on<GiftEvent>().listen(_record);
    ref.onDispose(() {
      _disposed = true;
      subscription.cancel();
    });
    // Если программу закрыли, пока подарок ждал ответа игры, ответ уже
    // не придёт: такие записи показываем как «Доставка не подтверждена».
    // Комбо, оборванное закрытием программы, считается завершённым.
    final initial = [
      for (final event in ref.read(initialDataProvider).history)
        event.copyWith(
          delivery: event.delivery == DeliveryStatus.sending
              ? DeliveryStatus.unconfirmed
              : event.delivery,
          comboActive: false,
          actionState: event.actionState == ActionState.pending
              ? ActionState.failed
              : event.actionState,
          actionResult: event.actionState == ActionState.pending
              ? 'программа закрылась до ответа игры'
              : event.actionResult,
        ),
    ];
    return EventLogState(events: List.unmodifiable(initial));
  }

  void _record(GiftEvent event) {
    if (_disposed) return;
    final comboId = event.comboId;
    if (comboId != null) {
      final index = state.events.indexWhere((e) => e.comboId == comboId);
      if (index >= 0) {
        _updateCombo(index, event);
        return;
      }
    }
    // Защита от повторной доставки одного и того же события.
    if (state.byId(event.id) != null) return;
    state = EventLogState(
      events: List.unmodifiable([event, ...state.events]),
      saveError: state.saveError,
    );
    _scheduleSave();
  }

  /// Очередной шаг комбо: счётчик растёт в той же записи.
  void _updateCombo(int index, GiftEvent step) {
    final current = state.events[index];
    final count = step.count > current.count ? step.count : current.count;
    // Завершённое комбо не «оживает» от запоздавшего шага.
    final active = current.comboActive && step.comboActive;
    if (count == current.count && active == current.comboActive) return;
    _replace(index, current.copyWith(count: count, comboActive: active));
  }

  /// Запись, которая не проходит через шину (проверка действия «Проверить
  /// в игре»): в журнал попадает, а подарком в игру не отправляется.
  void add(GiftEvent event) {
    if (_disposed || state.byId(event.id) != null) return;
    state = EventLogState(
      events: List.unmodifiable([event, ...state.events]),
      saveError: state.saveError,
    );
    _scheduleSave();
  }

  /// Результат действия паркура для записи.
  bool setAction(
    String id, {
    required ActionState actionState,
    String? title,
    String? result,
    DeliveryStatus? delivery,
    bool? unknownGift,
  }) {
    if (_disposed) return false;
    final index = state.events.indexWhere((event) => event.id == id);
    if (index < 0) return false;
    final current = state.events[index];
    _replace(
      index,
      current.copyWith(
        actionState: actionState,
        actionTitle: title,
        actionResult: result,
        delivery: delivery,
        deliveredCount: delivery == DeliveryStatus.delivered ? current.count : null,
        unknownGift: unknownGift,
      ),
    );
    return true;
  }

  /// Меняет статус доставки существующей записи и сохраняет историю.
  /// Возвращает `false`, если записи с таким id нет.
  bool setDelivery(String id, DeliveryStatus delivery, {int? deliveredCount}) {
    if (_disposed) return false;
    final index = state.events.indexWhere((event) => event.id == id);
    if (index < 0) return false;
    final current = state.events[index];
    final delivered = deliveredCount ??
        (delivery == DeliveryStatus.delivered && !current.isCombo
            ? current.count
            : current.deliveredCount);
    if (current.delivery == delivery && current.deliveredCount == delivered) {
      return true;
    }
    _replace(
      index,
      current.copyWith(delivery: delivery, deliveredCount: delivered),
    );
    return true;
  }

  void _replace(int index, GiftEvent updated) {
    final next = [...state.events];
    next[index] = updated;
    state = EventLogState(
      events: List.unmodifiable(next),
      saveError: state.saveError,
    );
    _scheduleSave();
  }

  /// Записи идут строго по очереди; каждая сохраняет актуальный список.
  void _scheduleSave() {
    final repository = ref.read(eventHistoryRepositoryProvider);
    final notices = ref.read(noticeServiceProvider);
    _pendingWrite = _pendingWrite.then((_) async {
      if (_disposed) return;
      try {
        await repository.save(state.events);
        if (!_disposed && state.saveError != null) {
          state = EventLogState(events: state.events);
        }
      } catch (error) {
        final detail = error is StorageException ? error.message : '$error';
        final message = 'Не удалось сохранить историю событий на диск. '
            'Событие видно в программе, но после перезапуска может пропасть. '
            '$detail';
        if (!_disposed) {
          state = EventLogState(events: state.events, saveError: message);
        }
        notices.error(message);
      }
    });
  }

  /// Дождаться окончания всех начатых записей на диск.
  Future<void> flush() => _pendingWrite;
}
