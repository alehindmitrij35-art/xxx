package dev.dirronlive.parkour.world;

import java.util.PriorityQueue;

/** Отложенные задачи по тикам сервера. */
public final class Scheduler {
    private record Task(long at, long order, Runnable action) {}

    private final PriorityQueue<Task> queue = new PriorityQueue<>((a, b) ->
            a.at != b.at ? Long.compare(a.at, b.at) : Long.compare(a.order, b.order));
    private long order;

    public void at(long tick, Runnable action) {
        queue.add(new Task(tick, order++, action));
    }

    public void run(long now) {
        while (!queue.isEmpty() && queue.peek().at <= now) {
            queue.poll().action.run();
        }
    }

    public void clear() {
        queue.clear();
    }

    public int size() {
        return queue.size();
    }
}
