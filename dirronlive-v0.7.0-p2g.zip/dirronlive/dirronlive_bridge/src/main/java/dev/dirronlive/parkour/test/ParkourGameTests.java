package dev.dirronlive.parkour.test;

import dev.dirronlive.parkour.map.ParkourLayout;
import dev.dirronlive.parkour.map.Platform;
import dev.dirronlive.parkour.map.RoomPlan;
import dev.dirronlive.parkour.world.ActionQueue;
import dev.dirronlive.parkour.world.ParkourActions;
import dev.dirronlive.parkour.world.ParkourWorld;
import dev.dirronlive.parkour.world.PlayerProgress;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * Проверки карты в настоящем Minecraft 1.21.1 (запускаются на GitHub
 * задачей runGametest). Каждая проверка в своей группе — они идут по очереди
 * и не мешают друг другу. В журнал пишется строка PARKOUR_CHECK ok|fail.
 */
public final class ParkourGameTests implements FabricGameTest {
    static final int BASE_X = 20_000, BASE_Y = 100, BASE_Z = 20_000;
    static final Set<Integer> BUILT = new HashSet<>();

    static ParkourWorld map(TestContext ctx, int... rooms) {
        ParkourWorld pw = ParkourWorld.get(ctx.getWorld().getServer());
        if (!pw.state.built || pw.state.baseX != BASE_X) {
            pw.state.baseX = BASE_X;
            pw.state.baseY = BASE_Y;
            pw.state.baseZ = BASE_Z;
            pw.state.built = true;
            BUILT.clear();
        }
        for (int r : rooms) {
            if (BUILT.add(r)) pw.buildRoom(r);
        }
        return pw;
    }

    static ServerPlayerEntity player(TestContext ctx, ParkourWorld pw, int room) {
        ServerPlayerEntity player = ctx.createMockCreativeServerPlayerInWorld();
        pw.tickPlayer(player); // «первое появление»
        pw.moveToRoom(player, room);
        return player;
    }

    static void check(TestContext ctx, String name, boolean ok, String details) {
        System.out.println("PARKOUR_CHECK " + (ok ? "ok" : "fail") + " | " + name + " | " + details);
        if (!ok) throw new AssertionError(name + ": " + details);
    }

    static boolean near(ServerPlayerEntity p, double x, double y, double z) {
        return p.getPos().distanceTo(new Vec3d(x, y, z)) < 0.6;
    }

    static Map<String, Object> params(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) m.put((String) kv[i], kv[i + 1]);
        return m;
    }

    // ---------------------------------------------------------------------

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p01_blocks", tickLimit = 100)
    public void allBlocksExistInThisMinecraft(TestContext ctx) {
        Set<String> used = new HashSet<>();
        for (int r = 1; r <= ParkourLayout.ROOMS; r++) {
            used.addAll(ParkourLayout.plan(0, 100, 0, r).blueprint.blocks().values());
            used.addAll(ParkourLayout.plan(2, 0, 100, 0, r).blueprint.blocks().values()); // Dirron Parkour 2
        }
        StringBuilder bad = new StringBuilder();
        for (String b : used) {
            if (ParkourWorld.parseState(b) == null) bad.append(b).append(' ');
        }
        check(ctx, "блоки карты", bad.length() == 0, used.size() + " видов блоков " + bad);
        ctx.complete();
    }

    /**
     * Dirron Parkour 2: комнаты из каждой локации ставятся в мир и через секунду
     * остаются точно такими, как в плане (растения и потолки не осыпаются).
     */
    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p01b_dp2_rooms", tickLimit = 200)
    public void secondMapRoomsStandInWorld(TestContext ctx) {
        var world = ctx.getWorld();
        int[] rooms = {7, 22, 35, 42, 53, 68, 83, 95, 100};
        int off = 45_000;
        Map<BlockPos, net.minecraft.block.BlockState> expect = new LinkedHashMap<>();
        for (int r : rooms) {
            RoomPlan plan = ParkourLayout.plan(2, 0, 100, 0, r);
            for (var e : plan.blueprint.blocks().entrySet()) {
                long k = e.getKey();
                BlockPos pos = new BlockPos(dev.dirronlive.parkour.map.Blueprint.keyX(k) + off,
                        dev.dirronlive.parkour.map.Blueprint.keyY(k), dev.dirronlive.parkour.map.Blueprint.keyZ(k) + off);
                var st = ParkourWorld.parseState(e.getValue());
                if (st == null) continue;
                world.setBlockState(pos, st, net.minecraft.block.Block.NOTIFY_LISTENERS | net.minecraft.block.Block.FORCE_STATE);
                expect.put(pos, st);
            }
        }
        ctx.waitAndRun(40, () -> {
            int wrong = 0;
            String first = "";
            for (var e : expect.entrySet()) {
                // Сравниваем сам блок: возраст кактуса и т. п. может смениться от случайных тиков.
                if (!world.getBlockState(e.getKey()).isOf(e.getValue().getBlock())) {
                    if (wrong++ == 0) first = e.getKey() + " ждали " + e.getValue() + ", стоит " + world.getBlockState(e.getKey());
                }
            }
            check(ctx, "Dirron Parkour 2: комнаты всех локаций и финала стоят как в плане", wrong == 0,
                    expect.size() + " блоков, не так: " + wrong + " " + first);
            ctx.complete();
        });
    }

    /** Dirron Parkour 2: биомы локаций есть в этой версии и ставятся в мир. */
    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p01c_dp2_biomes", tickLimit = 100)
    public void secondMapBiomesApply(TestContext ctx) {
        var world = ctx.getWorld();
        var biomes = world.getRegistryManager().get(net.minecraft.registry.RegistryKeys.BIOME);
        int[] rooms = {1, 16, 31, 46, 61, 76, 91, 100};
        StringBuilder bad = new StringBuilder();
        for (int i = 0; i < rooms.length; i++) {
            String id = dev.dirronlive.parkour.map.Theme.biome(2, rooms[i]);
            var entry = biomes.getEntry(net.minecraft.registry.RegistryKey.of(
                    net.minecraft.registry.RegistryKeys.BIOME, net.minecraft.util.Identifier.of(id)));
            if (entry.isEmpty()) {
                bad.append(" нет ").append(id);
                continue;
            }
            BlockPos from = new BlockPos(47_000 + i * 32, 96, 47_000);
            BlockPos to = from.add(15, 15, 15);
            int chunks = ParkourWorld.fillBiome(world, from, to, entry.get());
            if (chunks <= 0) bad.append(" не поставлен ").append(id);
            else if (!world.getBiome(from.add(8, 8, 8)).matchesId(net.minecraft.util.Identifier.of(id))) bad.append(" не тот ").append(id);
        }
        check(ctx, "Dirron Parkour 2: биомы локаций", bad.length() == 0, "8 биомов" + bad);
        ctx.complete();
    }

    /** Dirron Parkour 2: у игрока своя погода по локации, на 100-м — «Тьма». */
    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p01d_dp2_mood", tickLimit = 100)
    public void secondMapMoodPerPlayer(TestContext ctx) {
        var world = ctx.getWorld();
        dev.dirronlive.parkour.world.Atmosphere atm = new dev.dirronlive.parkour.world.Atmosphere();
        ServerPlayerEntity player = ctx.createMockCreativeServerPlayerInWorld();
        atm.tick(world, player, 1, 20);
        var forest = atm.shown(player);
        atm.tick(world, player, 100, 600);
        var finale = atm.shown(player);
        boolean dark = player.hasStatusEffect(net.minecraft.entity.effect.StatusEffects.DARKNESS);
        atm.tick(world, player, 61, 621);
        var nether = atm.shown(player);
        check(ctx, "Dirron Parkour 2: своя погода у игрока",
                forest != null && forest.rain() == 0f && finale.darkness() && dark && nether.timeOfDay() == 14500
                        && atm.changes == 3 && world.getTimeOfDay() % 24000 != 18000,
                forest + " → " + finale + " → " + nether + ", тьма " + dark + ", смен " + atm.changes);
        ctx.complete();
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p02_room_back", tickLimit = 200)
    public void roomBackFrom12LandsOnStartOf11(TestContext ctx) {
        ParkourWorld pw = map(ctx, 11, 12);
        ServerPlayerEntity player = player(ctx, pw, 12);
        ParkourActions.Outcome o = ParkourActions.apply(pw, player, "room_back", params("rooms", 1), "Тест");
        RoomPlan r11 = pw.plan(11);
        PlayerProgress p = pw.progress(player);
        check(ctx, "Комната назад", o.ok() && o.text().equals("Комната 12 → 11") && p.room == 11
                        && near(player, r11.spawnX, r11.spawnY, r11.spawnZ)
                        && !pw.world.getBlockState(player.getBlockPos().down()).isAir(),
                o.text() + ", комната " + p.room + ", позиция " + player.getBlockPos());
        check(ctx, "чекпоинт обновлён", p.cpX == r11.spawnX && p.cpZ == r11.spawnZ, "cp " + p.cpX + " " + p.cpZ);
        ctx.complete();
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p03_last", tickLimit = 200)
    public void toLastLevelFrom37(TestContext ctx) {
        ParkourWorld pw = map(ctx, 37, 100);
        ServerPlayerEntity player = player(ctx, pw, 37);
        ParkourActions.Outcome o = ParkourActions.apply(pw, player, "to_last_level", params(), "Тест");
        RoomPlan last = pw.plan(100);
        check(ctx, "На последний уровень", o.text().equals("Комната 37 → 100") && pw.progress(player).room == 100
                        && near(player, last.spawnX, last.spawnY, last.spawnZ)
                        && Math.abs(player.getYaw() - last.spawnYaw) < 1,
                o.text() + ", yaw " + player.getYaw() + " / " + last.spawnYaw);
        ctx.complete();
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p04_first", tickLimit = 200)
    public void toFirstLevelKeepsFallsAndTime(TestContext ctx) {
        ParkourWorld pw = map(ctx, 1, 50);
        ServerPlayerEntity player = player(ctx, pw, 50);
        PlayerProgress p = pw.progress(player);
        p.falls = 7;
        p.ticks = 1234;
        ParkourActions.Outcome o = ParkourActions.apply(pw, player, "to_first_level", params(), "Тест");
        RoomPlan first = pw.plan(1);
        check(ctx, "На первый уровень", o.text().equals("Комната 50 → 1") && p.room == 1 && p.falls == 7
                        && p.ticks >= 1234 && near(player, first.spawnX, first.spawnY, first.spawnZ),
                o.text() + ", падений " + p.falls + ", тиков " + p.ticks);
        ctx.complete();
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p05_push", tickLimit = 200)
    public void pushesFollowLookDirection(TestContext ctx) {
        ParkourWorld pw = map(ctx, 12);
        ServerPlayerEntity player = player(ctx, pw, 12);
        player.setYaw(0); // взгляд на +Z, «вправо» — это −X
        player.setVelocity(Vec3d.ZERO);
        ParkourActions.Outcome o = ParkourActions.apply(pw, player, "super_push", params("direction", "right"), "Тест");
        Vec3d v = player.getVelocity();
        check(ctx, "СУПЕР СИЛЬНЫЙ ТОЛЧОК вправо", o.text().equals("Суперсильный толчок вправо")
                && Math.abs(v.x + 1.8) < 0.01 && Math.abs(v.z) < 0.01 && Math.abs(v.y - 0.8) < 0.01, o.text() + " " + v);
        player.setVelocity(Vec3d.ZERO);
        o = ParkourActions.apply(pw, player, "push", params("direction", "forward", "strength", 1.0), "Тест");
        v = player.getVelocity();
        check(ctx, "Толчок вперёд", o.text().equals("Толчок вперёд") && Math.abs(v.z - 0.6) < 0.01
                && Math.abs(v.x) < 0.01, o.text() + " " + v);
        ctx.complete();
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p06_shield", tickLimit = 200)
    public void shieldCancelsHindrance(TestContext ctx) {
        ParkourWorld pw = map(ctx, 20);
        ServerPlayerEntity player = player(ctx, pw, 20);
        ParkourActions.apply(pw, player, "shield", params("charges", 1), "Роза");
        ParkourActions.Outcome o = ParkourActions.apply(pw, player, "room_back", params("rooms", 1), "Тест");
        check(ctx, "Щит от пакости", pw.progress(player).room == 20 && o.text().contains("погасил"), o.text());
        o = ParkourActions.apply(pw, player, "room_back", params("rooms", 1), "Тест");
        check(ctx, "после щита помеха снова работает", pw.progress(player).room == 19, o.text());
        ctx.complete();
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p07_bridge", tickLimit = 200)
    public void bridgeAppearsAndMapRestores(TestContext ctx) {
        ParkourWorld pw = map(ctx, 12);
        ServerPlayerEntity player = player(ctx, pw, 12);
        RoomPlan plan = pw.plan(12);
        int[] cell = plan.bridge.get(0);
        BlockPos pos = new BlockPos(cell[0], cell[1], cell[2]);
        var before = pw.world.getBlockState(pos);
        ParkourActions.Outcome o = ParkourActions.apply(pw, player, "viewer_bridge", params("seconds", 1), "Тест");
        check(ctx, "Мост зрителя появился", o.ok() && pw.world.getBlockState(pos).isOf(Blocks.LIME_STAINED_GLASS),
                o.text() + " " + plan.bridge.size() + " блоков");
        ctx.runAtTick(40, () -> {
            // Эффекты других проверок (они идут подряд в одном мире) могут ещё
            // действовать — смотрим только клетки моста.
            boolean bridgeGone = plan.bridge.stream()
                    .noneMatch(c -> pw.temp.isTemporary(new BlockPos(c[0], c[1], c[2])));
            check(ctx, "карта восстановлена после моста", pw.world.getBlockState(pos).equals(before) && bridgeGone,
                    "было " + before + ", стало " + pw.world.getBlockState(pos)
                            + ", клетки моста сняты: " + bridgeGone + ", других эффектов: " + pw.temp.activeCount());
            ctx.complete();
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p08_fall", tickLimit = 200)
    public void fallReturnsToCheckpoint(TestContext ctx) {
        ParkourWorld pw = map(ctx, 12);
        ServerPlayerEntity player = player(ctx, pw, 12);
        RoomPlan plan = pw.plan(12);
        int falls = pw.progress(player).falls;
        pw.teleport(player, plan.spawnX, plan.fallY - 3, plan.spawnZ, 0);
        ctx.runAtTick(5, () -> {
            PlayerProgress p = pw.progress(player);
            check(ctx, "падение → чекпоинт", p.falls == falls + 1 && near(player, p.cpX, p.cpY, p.cpZ),
                    "падений " + p.falls + ", позиция " + player.getPos());
            ctx.complete();
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p09_finish", tickLimit = 200)
    public void finishOpensNextRoom(TestContext ctx) {
        ParkourWorld pw = map(ctx, 12, 13);
        ServerPlayerEntity player = player(ctx, pw, 12);
        Platform f = pw.plan(12).finish();
        pw.teleport(player, f.centerX(), f.y() + 1, f.centerZ(), 0);
        ctx.runAtTick(5, () -> {
            check(ctx, "финиш комнаты 12 → комната 13", pw.progress(player).room == 13,
                    "комната " + pw.progress(player).room);
            ctx.complete();
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p10_victory", tickLimit = 200)
    public void victoryLightsLogoEyes(TestContext ctx) {
        ParkourWorld pw = map(ctx, 100);
        ServerPlayerEntity player = player(ctx, pw, 100);
        RoomPlan plan = pw.plan(100);
        Platform f = plan.finish();
        pw.teleport(player, f.centerX(), f.y() + 1, f.centerZ(), 0);
        ctx.runAtTick(5, () -> {
            int lit = 0;
            for (int[] e : plan.eyes) {
                if (pw.world.getBlockState(new BlockPos(e[0], e[1], e[2])).isOf(Blocks.VERDANT_FROGLIGHT)) lit++;
            }
            check(ctx, "победа и зелёные глаза", pw.progress(player).finished && lit == plan.eyes.size(),
                    "глаз горит " + lit + " из " + plan.eyes.size());
            pw.lightEyes(false);
            ctx.complete();
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p11_effects", tickLimit = 200)
    public void allCatalogActionsAnswer(TestContext ctx) {
        ParkourWorld pw = map(ctx, 30, 31, 29, 25, 1, 100);
        ServerPlayerEntity player = player(ctx, pw, 30);
        StringBuilder report = new StringBuilder();
        boolean ok = true;
        for (String id : ParkourActions.TITLES.keySet()) {
            if (id.equals("second_chance")) continue; // отсчёт ведёт Dirronlive
            pw.moveToRoom(player, 30);
            ParkourActions.Outcome o = ParkourActions.apply(pw, player, id, params(), "Тест");
            report.append(id).append('=').append(o.text()).append("; ");
            ok &= o.ok() || id.equals("vanishing_step");
        }
        ParkourActions.unfreeze(player);
        check(ctx, "все действия каталога отвечают", ok, report.toString());
        ctx.complete();
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p12_queue", tickLimit = 400)
    public void seriesQueueRunsEveryUnitOnceWithoutLimit(TestContext ctx) {
        ParkourWorld pw = map(ctx, 7, 8, 9, 10, 11, 12);
        ServerPlayerEntity player = player(ctx, pw, 12);
        PlayerProgress p = pw.progress(player);
        int charges = p.rescueCharges;
        // ×1000 «Спасений»: очередь принимает тысячу, выполняет порциями по тикам.
        ActionQueue.Job rescue = pw.actions.submit(player, "q-rescue", "fall_rescue", params(), "Тест", 1000, null);
        check(ctx, "очередь приняла ×1000", rescue.accepted() == 1000 && rescue.done() == 0,
                "принято " + rescue.accepted() + ", выполнено " + rescue.done());
        // Нарастающая серия ×1 → ×5: room_back ровно пять раз.
        for (int n = 1; n <= 5; n++) pw.actions.submit(player, "q-back", "room_back", params("rooms", 1), "Тест", n, null);
        // Пушки: 20 отдельных импульсов.
        player.setYaw(0);
        ActionQueue.Job push = pw.actions.submit(player, "q-push", "push", params("direction", "left"), "Тест", 20, null);
        ctx.runAtTick(30, () -> {
            check(ctx, "серия ×1000 выполнена ровно 1000 раз", rescue.done() == 1000
                            && pw.progress(player).rescueCharges == charges + 1000,
                    "выполнено " + rescue.done() + ", зарядов +" + (pw.progress(player).rescueCharges - charges));
            // Повтор события после переподключения: total тот же — ничего не добавляется.
            pw.actions.submit(player, "q-rescue", "fall_rescue", params(), "Тест", 1000, null);
            pw.actions.submit(player, "q-back", "room_back", params("rooms", 1), "Тест", 5, null);
            check(ctx, "повтор ×1000 не добавляет", rescue.accepted() == 1000, "принято " + rescue.accepted());
            check(ctx, "серия ×1→×5: Комната 12 → 7", pw.progress(player).room == 7
                            && ActionQueue.summary(pw.actions.job("q-back"), 7).equals("Комната 12 → 7 (×5)"),
                    "комната " + pw.progress(player).room + ", " + ActionQueue.summary(pw.actions.job("q-back"), 7));
        });
        ctx.runAtTick(120, () -> {
            check(ctx, "20 толчков — 20 отдельных импульсов", push.done() == 20,
                    "выполнено " + push.done() + " из " + push.accepted());
            check(ctx, "повтор не добавил комнат", pw.progress(player).room == 7, "комната " + pw.progress(player).room);
            ctx.complete();
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p13_level", tickLimit = 200)
    public void levelIndicatorFollowsRoom(TestContext ctx) {
        ParkourWorld pw = map(ctx, 1, 37, 100);
        ServerPlayerEntity player = player(ctx, pw, 37);
        check(ctx, "индикатор: ПРОЙДЕНО 36 / 100", pw.levelBarText(player).equals("ПРОЙДЕНО 36 / 100"),
                pw.levelBarText(player));
        ParkourActions.apply(pw, player, "to_last_level", params(), "Тест");
        check(ctx, "индикатор после «На последний уровень»", pw.levelBarText(player).equals("ПРОЙДЕНО 99 / 100"),
                pw.levelBarText(player));
        ParkourActions.apply(pw, player, "to_first_level", params(), "Тест");
        check(ctx, "индикатор после «На первый уровень»", pw.levelBarText(player).equals("ПРОЙДЕНО 0 / 100"),
                pw.levelBarText(player));
        pw.moveToRoom(player, 100);
        Platform f = pw.plan(100).finish();
        pw.teleport(player, f.centerX(), f.y() + 1, f.centerZ(), 0);
        ctx.runAtTick(5, () -> {
            check(ctx, "после финиша 100: «ПРОЙДЕНО 100 / 100»", pw.levelBarText(player).equals("ПРОЙДЕНО 100 / 100"),
                    pw.levelBarText(player));
            // Сохранение прогресса: запись и чтение как при перезаходе.
            PlayerProgress saved = pw.progress(player);
            var nbt = pw.state.writeNbt(new net.minecraft.nbt.NbtCompound(), ctx.getWorld().getRegistryManager());
            check(ctx, "прогресс сохраняется в мире", nbt.getCompound("players").getKeys()
                    .contains(player.getUuidAsString()) && saved.bestRoom == 100, "рекорд " + saved.bestRoom);
            pw.lightEyes(false);
            ctx.complete();
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "p14_attempts", tickLimit = 200)
    public void fallAddsAttemptTeleportDoesNot(TestContext ctx) {
        ParkourWorld pw = map(ctx, 12, 13);
        ServerPlayerEntity player = player(ctx, pw, 12);
        RoomPlan plan = pw.plan(12);
        pw.teleport(player, plan.spawnX, plan.fallY - 3, plan.spawnZ, 0);
        ctx.runAtTick(5, () -> {
            check(ctx, "падение → попытка 2", pw.progress(player).roomFalls == 1,
                    "падений в комнате " + pw.progress(player).roomFalls);
            ParkourActions.apply(pw, player, "room_forward", params("rooms", 1), "Тест");
            check(ctx, "телепорт не прибавляет попытку", pw.progress(player).roomFalls == 0
                    && pw.progress(player).room == 13, "падений в комнате " + pw.progress(player).roomFalls);
            ctx.complete();
        });
    }
}
