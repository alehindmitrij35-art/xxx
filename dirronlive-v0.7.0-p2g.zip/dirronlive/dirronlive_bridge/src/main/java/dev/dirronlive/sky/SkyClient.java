package dev.dirronlive.sky;

import dev.dirronlive.sky.core.FlightAssist;
import dev.dirronlive.sky.core.V3;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Клиентская часть полёта: поправки скорости каждый тик прямо у игрока
 * (восходящие потоки, эффекты зрителей, предел скорости) — без пакетов
 * с сервера, поэтому полёт плавный. И клавиша быстрого рестарта.
 */
public final class SkyClient {
    private SkyClient() {}

    private static boolean keyWasDown;
    private static long ticks;

    public static void tick(MinecraftClient client) {
        ticks++;
        ClientPlayerEntity player = client.player;
        if (player == null) return;
        SkyWorld.ClientView view = SkyWorld.view;
        if (view.flying() && view.track() != null && player.getUuid().equals(view.player()) && player.isFallFlying()) {
            Vec3d v = player.getVelocity();
            V3 vel = new V3(v.x, v.y, v.z);
            V3 pos = new V3(player.getX(), player.getY() + 0.3, player.getZ());
            V3 next = FlightAssist.adjust(pos, vel, view.track().zonesAt(pos), view.track().speedCap, view.forces(), ticks);
            if (next != vel) player.setVelocity(next.x(), next.y(), next.z());
        }
        restartKey(client, player.getUuid());
        SkyRender.particles(client);
    }

    static void restartKey(MinecraftClient client, UUID uuid) {
        int code = keyCode(SkyConfig.settings.restartKey());
        boolean down = code > 0 && client.currentScreen == null
                && InputUtil.isKeyPressed(client.getWindow().getHandle(), code);
        boolean pressed = down && !keyWasDown;
        keyWasDown = down;
        if (!pressed || !"ready".equals(SkyWorld.lastStatus.map())) return;
        IntegratedServer server = client.getServer();
        if (server == null) return;
        server.execute(() -> {
            ServerPlayerEntity sp = server.getPlayerManager().getPlayer(uuid);
            if (sp != null) SkyWorld.get(server).command(sp, "restart");
        });
    }

    /** «R» → код клавиши GLFW; «NONE» или неизвестное → 0 (выключено). */
    public static int keyCode(String key) {
        if (key == null || key.isEmpty() || key.equals("NONE")) return 0;
        if (key.length() == 1) {
            char c = key.charAt(0);
            if (c >= 'A' && c <= 'Z') return c;
            if (c >= '0' && c <= '9') return c;
            return 0;
        }
        if (key.matches("F([1-9]|1[0-2])")) return 289 + Integer.parseInt(key.substring(1));
        return 0;
    }
}
