package dev.dirronlive.sky.core;

import java.util.List;

/**
 * Поправки к скорости полёта на элитрах за один тик: восходящие потоки,
 * эффекты зрителей и предел скорости. Чистая функция: одинаково работает
 * в игре и в тестах.
 */
public final class FlightAssist {
    private FlightAssist() {}

    /** Восходящий поток не разгоняет вверх быстрее этого (блоков за тик). */
    public static final double MAX_LIFT_SPEED = 0.9;
    /** На сколько блоков от верха зоны поток начинает слабеть. */
    public static final double LIFT_FADE = 8;

    /**
     * @param tick номер тика — для повторяемой тряски
     * @return новая скорость или тот же объект {@code vel}, если ничего не изменилось
     */
    public static V3 adjust(V3 pos, V3 vel, List<Zone> zones, double cap, Forces f, long tick) {
        V3 v = vel;
        for (Zone z : zones) {
            if (z.kind() != Zone.Kind.LIFT || !z.contains(pos)) continue;
            // Поток слабеет к верху зоны — игрок выходит на высоту следующего кольца, а не выше.
            double fade = Math.max(0, Math.min(1, (z.max().y() - pos.y()) / LIFT_FADE));
            double limit = MAX_LIFT_SPEED * fade;
            if (v.y() < limit) v = new V3(v.x(), Math.min(limit, v.y() + z.strength() * Math.max(0.25, fade)), v.z());
        }
        if (f != null && !f.isNone()) {
            v = v.add(f.push());
            if (f.tailwind() != 0) {
                V3 dir = new V3(v.x(), 0, v.z()).normalize();
                v = v.add(dir.mul(f.tailwind()));
            }
            if (f.sink() != 0) v = v.add(0, -f.sink(), 0);
            if (f.drag() != 1) v = new V3(v.x() * f.drag(), v.y(), v.z() * f.drag());
            if (f.turbulence() > 0) {
                double a = f.turbulence();
                v = v.add(wave(tick, 0) * a, wave(tick, 1) * a * 0.6, wave(tick, 2) * a);
            }
            cap *= f.capFactor();
        }
        double len = v.length();
        if (cap > 0 && len > cap) v = v.mul(cap / len);
        return v.equals(vel) ? vel : v;
    }

    /** Плавная повторяемая «тряска» в диапазоне −1…1. */
    static double wave(long tick, int axis) {
        double t = tick / 20.0;
        return switch (axis) {
            case 0 -> Math.sin(t * 5.3) * 0.6 + Math.sin(t * 11.7 + 1.3) * 0.4;
            case 1 -> Math.sin(t * 7.1 + 2.1) * 0.7 + Math.sin(t * 13.9) * 0.3;
            default -> Math.sin(t * 6.1 + 4.2) * 0.6 + Math.sin(t * 9.4 + 0.7) * 0.4;
        };
    }
}
