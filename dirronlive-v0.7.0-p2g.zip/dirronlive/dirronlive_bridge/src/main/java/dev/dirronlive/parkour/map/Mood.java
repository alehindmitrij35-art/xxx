package dev.dirronlive.parkour.map;

/**
 * Погода и мрачность локации Dirron Parkour 2 — у каждого игрока своя, по
 * его комнате. Чем дальше по карте, тем темнее: ясное утро в лесу, снегопад
 * в горах, золотой вечер в пустыне, дождливые сумерки на рифе, ночь в Аду,
 * полночь в Энде, ночная гроза в «Разломе» и полная тьма на 100-м уровне.
 *
 * @param timeOfDay   время суток для игрока (0 — рассвет, 6000 — полдень, 18000 — полночь)
 * @param rain        сила дождя 0..1 (в снежном биоме это снег, в сухих биомах — только тёмное небо)
 * @param thunder     сила грозы 0..1 (темнее неба, вспышки)
 * @param lightning   изредка бьют молнии вдали (только вид и звук)
 * @param darkness    накатывающая тьма (эффект «Тьма») и жуткие звуки
 * @param gloom       мрачность 0..10 — для проверки, что карта темнеет к концу
 */
public record Mood(String title, long timeOfDay, float rain, float thunder, boolean lightning, boolean darkness, int gloom) {

    public static Mood forRoom(int variant, int room) {
        if (variant != 2) return null;
        if (room == ParkourLayout.ROOMS) return new Mood("Последняя тьма: полночь, буря и тьма", 18000, 1f, 1f, true, true, 10);
        return switch (Theme.forRoom(2, room)) {
            case FOREST -> new Mood("Ясное утро", 1000, 0f, 0f, false, false, 0);
            case MOUNTAIN -> new Mood("Снегопад", 4000, 1f, 0f, false, false, 2);
            case DESERT -> new Mood("Золотой вечер", 11200, 0f, 0f, false, false, 3);
            case REEF -> new Mood("Дождливые сумерки", 12700, 1f, 0f, false, false, 5);
            case NETHER -> new Mood("Багровая ночь", 14500, 0.7f, 0f, false, false, 6);
            case END_ISLES -> new Mood("Полночь Энда", 18000, 0f, 0f, false, false, 8);
            default -> new Mood("Ночная гроза", 17000, 1f, 1f, true, false, 9); // RIFT
        };
    }
}
