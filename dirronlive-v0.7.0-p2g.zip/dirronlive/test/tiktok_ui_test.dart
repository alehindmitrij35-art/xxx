import 'package:dirronlive/features/settings/settings_controller.dart';
import 'package:dirronlive/features/tiktok/tiktok_controller.dart';
import 'package:dirronlive/ui/screens/settings_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fake_tiktok.dart';
import 'support/memory_store.dart';
import 'support/test_app.dart';

Finder statusText(Key where, String text) =>
    find.descendant(of: find.byKey(where), matching: find.text(text));

void main() {
  testWidgets(
      'Подключиться → Эфир не найден → Повторить → Подключено → Отключиться',
      (tester) async {
    final backend = FakeTikTokBackend();
    final container = await pumpDirronlive(
      tester,
      MemoryJsonStore(),
      overrides: [tiktokBackendProvider.overrideWithValue(backend)],
    );

    await openSection(tester, 'settings');
    expect(find.text('Подключиться'), findsOneWidget);
    await tester.enterText(
        find.byKey(SettingsScreen.nicknameFieldKey), '  @dirron_live ');
    await tester.tap(find.byKey(SettingsScreen.tiktokConnectKey));
    await tester.pumpAndSettle();

    // Ник сохранён и нормализован, коннектор запущен для этого аккаунта.
    expect(container.read(settingsProvider).tiktokNickname, 'dirron_live');
    expect(backend.last.uniqueId, 'dirron_live');
    expect(statusText(const Key('tiktok-status'), 'Подключение…'), findsOneWidget);
    expect(find.text('Отключиться'), findsOneWidget);

    // Эфир ещё не идёт.
    backend.last.status('offline');
    backend.last.exit();
    await tester.pumpAndSettle();
    expect(statusText(const Key('tiktok-status'), 'Эфир не найден'), findsOneWidget);
    expect(find.byKey(const Key('tiktok-message')), findsOneWidget);
    expect(find.text('Повторить'), findsOneWidget);

    // На «Эфире» — тот же статус.
    await openSection(tester, 'live');
    expect(statusText(const Key('strip-tiktok'), 'Эфир не найден'), findsOneWidget);

    // Трансляция запущена — «Повторить».
    await openSection(tester, 'settings');
    await tester.tap(find.byKey(SettingsScreen.tiktokConnectKey));
    await tester.pumpAndSettle();
    backend.last.connected();
    await tester.pumpAndSettle();
    expect(statusText(const Key('tiktok-status'), 'Подключено'), findsOneWidget);

    await openSection(tester, 'live');
    expect(statusText(const Key('strip-tiktok'), 'Подключено'), findsOneWidget);

    // Подарок из эфира — в ленте с ником и «Роза ×5».
    final session = backend.last;
    for (var n = 1; n <= 5; n++) {
      session.gift(nickname: 'Alex', groupId: 'g', repeatCount: n, repeatEnd: n == 5);
    }
    await tester.pumpAndSettle();
    expect(find.text('Alex'), findsOneWidget);
    expect(find.text('Роза ×5'), findsOneWidget);

    // Отключиться.
    await openSection(tester, 'settings');
    await tester.tap(find.byKey(SettingsScreen.tiktokDisconnectKey));
    await tester.pumpAndSettle();
    expect(statusText(const Key('tiktok-status'), 'Не подключено'), findsOneWidget);
    expect(session.stopped, isTrue);

    await closeDirronlive(tester, container);
  });

  testWidgets('без ника подключиться нельзя — понятная подсказка',
      (tester) async {
    final backend = FakeTikTokBackend();
    final container = await pumpDirronlive(
      tester,
      MemoryJsonStore(),
      overrides: [tiktokBackendProvider.overrideWithValue(backend)],
    );
    await openSection(tester, 'settings');
    await tester.tap(find.byKey(SettingsScreen.tiktokConnectKey));
    await tester.pumpAndSettle();
    expect(backend.sessions, isEmpty);
    expect(find.text('Сначала укажите ник TikTok.'), findsOneWidget);
    await closeDirronlive(tester, container);
  });
}
