// Критерий готовности, пройденный через настоящий интерфейс с новой
// навигацией: сохранить ник, трижды нажать «Тестовый подарок», увидеть три
// записи на «Эфире» и в «Истории», «перезапустить» программу и увидеть то
// же самое. TikTok — «Не подключено», связь с игрой — «Связь выключена».

import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/ui/screens/history_screen.dart';
import 'package:dirronlive/ui/screens/live_screen.dart';
import 'package:dirronlive/ui/screens/overlays_screen.dart';
import 'package:dirronlive/ui/screens/settings_screen.dart';
import 'package:dirronlive/ui/widgets/event_tile.dart';
import 'package:dirronlive/ui/widgets/test_gift_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/memory_store.dart';
import 'support/test_app.dart';

const feedGift = 'Роза ×1';

void expectStripStatuses({String minecraft = 'Связь выключена'}) {
  expect(
    find.descendant(
      of: find.byKey(const Key('strip-tiktok')),
      matching: find.text('Не подключено'),
    ),
    findsOneWidget,
  );
  expect(
    find.descendant(
      of: find.byKey(const Key('strip-minecraft')),
      matching: find.text(minecraft),
    ),
    findsOneWidget,
  );
}

void main() {
  testWidgets('полный сценарий: ник, три подарка, перезапуск', (tester) async {
    final store = MemoryJsonStore();

    // ── Первый запуск: стартовый экран — «Эфир» ───────────────────
    var container = await pumpDirronlive(tester, store);
    expect(find.text('Dirronlive'), findsOneWidget);
    expect(find.byType(LiveScreen), findsOneWidget);
    expect(find.text(LiveScreen.emptyHint), findsOneWidget);
    expect(find.byType(EventTile), findsNothing);
    expect(find.byKey(const Key('current-mode-title')), findsOneWidget);
    expect(find.text('Dirron Parkour: 100 комнат'), findsOneWidget);
    expectStripStatuses();

    // ── Ник: Настройки → Подключения → TikTok LIVE ───────────────
    await openSection(tester, 'settings');
    expect(find.text('Подключения'), findsOneWidget);
    await tester.enterText(
        find.byKey(SettingsScreen.nicknameFieldKey), '   @dirron_live  ');
    await tester.tap(find.byKey(SettingsScreen.saveButtonKey));
    await tester.pumpAndSettle();
    final field =
        tester.widget<TextField>(find.byKey(SettingsScreen.nicknameFieldKey));
    expect(field.controller!.text, 'dirron_live');
    expect(find.text('Ник сохранён: @dirron_live'), findsOneWidget);

    // ── Три быстрых нажатия на «Эфире» ────────────────────────────
    await openSection(tester, 'live');
    final button = find.byKey(TestGiftButton.buttonKey);
    await tester.tap(button);
    await tester.tap(button);
    await tester.tap(button);
    await tester.pumpAndSettle();

    expect(find.byType(EventTile), findsNWidgets(3));
    // Ник зрителя и «Роза ×1» одной строкой в каждой записи.
    expect(
      find.descendant(
        of: find.byKey(LiveScreen.feedKey),
        matching: find.text('Тестовый зритель'),
      ),
      findsNWidgets(3),
    );
    expect(find.text(feedGift), findsNWidgets(3));
    expect(find.text('Всего: 3'), findsOneWidget);
    // Связь выключена — все три только в журнале.
    expect(
      find.descendant(
        of: find.byKey(LiveScreen.feedKey),
        matching: find.text('Только в журнале'),
      ),
      findsNWidgets(3),
    );
    expectStripStatuses();

    // ── История: те же три записи с доставкой ─────────────────────
    await openSection(tester, 'history');
    expect(find.byType(HistoryRow), findsNWidgets(3));
    expect(find.text('Роза'), findsNWidgets(3));
    expect(find.text('Тестовый зритель'), findsNWidgets(3));
    expect(find.text('Тест'), findsNWidgets(3));
    expect(find.text('×1'), findsNWidgets(3));
    expect(find.text('Только в журнале'), findsNWidgets(3));

    // Переходы по всем разделам не дублируют записи.
    for (final section in [
      'live', 'modes', 'overlays', 'history', 'settings', 'live',
    ]) {
      await openSection(tester, section);
    }
    expect(find.byType(EventTile), findsNWidgets(3));
    final idsBefore =
        container.read(eventLogProvider).events.map((e) => e.id).toList();
    expect(idsBefore.toSet().length, 3);

    // ── Перезапуск ───────────────────────────────────────────────
    await closeDirronlive(tester, container);
    container = await pumpDirronlive(tester, store);

    expect(
      container.read(eventLogProvider).events.map((e) => e.id).toList(),
      idsBefore,
    );
    expect(find.byType(EventTile), findsNWidgets(3));
    expectStripStatuses();

    await openSection(tester, 'history');
    expect(find.byType(HistoryRow), findsNWidgets(3));

    await openSection(tester, 'settings');
    final restoredField =
        tester.widget<TextField>(find.byKey(SettingsScreen.nicknameFieldKey));
    expect(restoredField.controller!.text, 'dirron_live');

    await closeDirronlive(tester, container);
  });

  testWidgets('лента прокручивается, кнопка остаётся на месте', (tester) async {
    final container = await pumpDirronlive(tester, MemoryJsonStore());
    final button = find.byKey(TestGiftButton.buttonKey);
    final buttonRect = tester.getRect(button);

    for (var i = 0; i < 30; i++) {
      await tester.tap(button);
      if (i == 0 || i == 11 || i == 29) {
        await tester.pump();
        expectNoFlutterError(tester, 'нажатие ${i + 1}');
      }
    }
    await tester.pumpAndSettle();
    expectNoFlutterError(tester, 'после 30 нажатий');
    expect(find.text('Всего: 30'), findsOneWidget);
    expect(tester.getRect(button), buttonRect);

    // Новая запись сверху и видна.
    final newest = container.read(eventLogProvider).events.first;
    final feed = find.byKey(LiveScreen.feedKey);
    expect(isFullyVisibleIn(tester, find.byKey(ValueKey(newest.id)), feed),
        isTrue);

    await tester.drag(find.byKey(LiveScreen.feedKey), const Offset(0, -600));
    await tester.pumpAndSettle();
    expectNoFlutterError(tester, 'прокрутка ленты');
    expect(tester.getRect(button), buttonRect);
    expect(isFullyVisibleIn(tester, find.byKey(ValueKey(newest.id)), feed),
        isFalse);

    await closeDirronlive(tester, container);
  });

  testWidgets('ошибка записи на диск показывается по-русски', (tester) async {
    final store = MemoryJsonStore()..failWrites = true;
    final container = await pumpDirronlive(tester, store);
    await tester.tap(find.byKey(TestGiftButton.buttonKey));
    await tester.pumpAndSettle();

    expect(find.byType(EventTile), findsOneWidget);
    expect(find.textContaining('Не удалось сохранить историю событий'),
        findsWidgets);

    await openSection(tester, 'settings');
    await tester.enterText(find.byKey(SettingsScreen.nicknameFieldKey), 'x');
    await tester.tap(find.byKey(SettingsScreen.saveButtonKey));
    await tester.pumpAndSettle();
    expect(find.textContaining('Не удалось сохранить настройки'), findsOneWidget);

    await closeDirronlive(tester, container);
  });

  testWidgets('режимы сеткой и оверлеи на всю область', (tester) async {
    final container = await pumpDirronlive(tester, MemoryJsonStore());

    await tester.tap(find.byKey(const Key('view-modes')));
    await tester.pumpAndSettle();
    expect(find.text('Dirron Parkour: 100 комнат'), findsOneWidget);
    expect(find.text('Побег из лабиринта'), findsOneWidget);
    expect(find.text('Evolution Chaos'), findsOneWidget);
    expect(find.text('Небесный разлом'), findsOneWidget);
    expect(find.text('Dirron Parkour 2'), findsOneWidget);
    expect(find.text('Готов'), findsNWidgets(3));
    expect(find.text('В планах'), findsNWidgets(2));
    // На широком экране — три карточки в один ряд.
    final tops = [
      for (final id in ['dirron_parkour_100', 'dirron_parkour_2', 'sky_rift'])
        tester.getTopLeft(find.byKey(ValueKey('mode-$id'))).dy,
    ];
    expect(tops.toSet().length, 1);

    await openSection(tester, 'overlays');
    expect(find.text(OverlaysScreen.message), findsOneWidget);
    final area = tester.getSize(find.byKey(const Key('overlays-area')));
    expect(area.width, greaterThan(1800));
    expect(area.height, greaterThan(900));

    await closeDirronlive(tester, container);
  });

  testWidgets('тестовое комбо: одна запись, счётчик растёт до ×10',
      (tester) async {
    final container = await pumpDirronlive(tester, MemoryJsonStore());
    final comboButton = find.byKey(const Key('test-combo-button'));
    await tester.tap(comboButton);
    await tester.pump();
    expect(find.text('Комбо идёт… ×1'), findsOneWidget);
    expect(find.byType(EventTile), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 650));
    expect(find.text('Комбо идёт… ×3'), findsOneWidget);
    expect(find.textContaining('комбо идёт…'), findsOneWidget);

    await tester.pump(const Duration(seconds: 3));
    await tester.pumpAndSettle();
    expect(find.byType(EventTile), findsOneWidget);
    expect(find.text('Роза ×10'), findsOneWidget);
    expect(find.text('Тестовое комбо ×10'), findsOneWidget);
    expect(container.read(eventLogProvider).events.single.count, 10);
    expect(container.read(eventLogProvider).events.single.comboActive, isFalse);

    await openSection(tester, 'history');
    expect(find.byType(HistoryRow), findsOneWidget);
    expect(find.text('×10 комбо'), findsOneWidget);
    await closeDirronlive(tester, container);
  });

  testWidgets('новая запись на 0,7 с подсвечивается слева', (tester) async {
    final container = await pumpDirronlive(tester, MemoryJsonStore());
    await tester.tap(find.byKey(TestGiftButton.buttonKey));
    await tester.pump();
    final id = container.read(eventLogProvider).events.single.id;
    expect(find.byKey(ValueKey('highlight-$id')), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 500));
    expect(find.byKey(ValueKey('highlight-$id')), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 300));
    await tester.pumpAndSettle();
    expect(find.byKey(ValueKey('highlight-$id')), findsNothing);
    await closeDirronlive(tester, container);
  });
}
