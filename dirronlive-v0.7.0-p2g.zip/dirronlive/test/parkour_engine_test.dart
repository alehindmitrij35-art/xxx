// Правила «подарок → действие» против настоящего WebSocket и «поддельного
// мода» 2.0, который ведёт себя как карта Dirron Parkour.

import 'dart:io';

import 'package:dirronlive/bootstrap.dart';
import 'package:dirronlive/core/events/delivery_status.dart';
import 'package:dirronlive/core/events/event_source.dart';
import 'package:dirronlive/core/events/gift_event.dart';
import 'package:dirronlive/core/events/stream_events.dart';
import 'package:dirronlive/core/initial_data.dart';
import 'package:dirronlive/core/providers.dart';
import 'package:dirronlive/features/events/event_log.dart';
import 'package:dirronlive/features/minecraft/minecraft_link.dart';
import 'package:dirronlive/features/parkour/action_catalog.dart';
import 'package:dirronlive/features/parkour/gift_catalog.dart';
import 'package:dirronlive/features/parkour/parkour_engine.dart';
import 'package:dirronlive/features/parkour/parkour_rules.dart';
import 'package:dirronlive/features/settings/settings_controller.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'support/fake_mod.dart';
import 'support/memory_store.dart';

class FakeFetcher implements GiftCatalogFetcher {
  List<CatalogGift> gifts = const [];
  CatalogFetchException? error;
  int calls = 0;
  String? lastUniqueId;

  @override
  Future<List<CatalogGift>> fetch({String? uniqueId, String? apiKey}) async {
    lastUniqueId = uniqueId;
    calls++;
    if (error != null) throw error!;
    return gifts;
  }
}

class Rig {
  Rig._(this.container, this.store, this.fetcher);

  static Future<Rig> start(
      {MemoryJsonStore? store, Duration timeout = const Duration(seconds: 1), GiftCatalog? snapshot}) async {
    final memory = store ?? MemoryJsonStore();
    final fetcher = FakeFetcher();
    final container = createAppContainer(
      await loadInitialData(memory),
      overrides: [
        minecraftLinkConfigProvider.overrideWithValue(MinecraftLinkConfig(
          port: 0,
          ackTimeout: timeout,
          pingInterval: const Duration(seconds: 1),
        )),
        giftCatalogFetcherProvider.overrideWithValue(fetcher),
        giftSnapshotProvider.overrideWithValue(snapshot),
      ],
    );
    final rig = Rig._(container, memory, fetcher);
    await rig.container.read(minecraftLinkProvider.notifier).start();
    return rig;
  }

  final ProviderContainer container;
  final MemoryJsonStore store;
  final FakeFetcher fetcher;
  FakeMod? mod;

  ParkourEngine get engine => container.read(parkourEngineProvider);
  ParkourRulesController get rules => container.read(parkourRulesProvider.notifier);
  List<GiftEvent> get events => container.read(eventLogProvider).events;

  Future<FakeMod> connectMod({int room = 12}) async {
    final m = await FakeMod.connect(container.read(minecraftLinkProvider).port!);
    m.respondToActions = true;
    m.helloParkour(room: room);
    await waitFor(() => container.read(minecraftLinkProvider).parkourReady, reason: 'карта готова');
    mod = m;
    return m;
  }

  GiftRule rule(String gift, String action, {Map<String, Object?> params = const {}, String? giftId}) {
    final a = parkourActionById(action)!;
    return GiftRule(
      id: newRuleId(),
      giftName: gift,
      giftId: giftId,
      actionId: action,
      params: a.normalize({...a.defaults(), ...params}),
    );
  }

  void tiktokGift(String name,
          {int count = 1, String? comboId, bool active = false, String? giftId, String viewer = 'Alex', String? key}) =>
      container.read(eventBusProvider).publish(GiftEvent(
            id: generateEventId(),
            createdAt: DateTime.now(),
            source: EventSource.tiktok,
            viewerName: viewer,
            viewerId: viewer.toLowerCase(),
            giftName: name,
            count: count,
            comboId: comboId,
            comboActive: active,
            giftId: giftId,
            sourceKey: key ?? comboId,
          ));

  GiftEvent? get first => events.isEmpty ? null : events.first;

  Future<void> close() async {
    await mod?.close();
    await container.read(minecraftLinkProvider.notifier).stop();
    await container.read(eventLogProvider.notifier).flush();
    container.dispose();
  }
}

void main() {
  test('новая настройка — четыре готовые карточки без подарков', () async {
    final rig = await Rig.start();
    final rules = rig.container.read(parkourRulesProvider).rules;
    expect(rules.map((r) => r.actionId), ['push', 'super_push', 'to_first_level', 'to_last_level']);
    expect(rules.every((r) => !r.hasGift), isTrue);
    await rig.close();
  });

  test('«Проверить в игре»: комната 12 → 11 и запись «Тест · Комната 12 → 11»', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 12);
    final outcome = await rig.engine.test(rig.rule('Роза', 'room_back'));

    expect(outcome.ok, isTrue);
    expect(outcome.text, 'Тест · Комната 12 → 11');
    expect(mod.actions, hasLength(1));
    expect(mod.actions.single['action'], 'room_back');
    expect(mod.actions.single['test'], isTrue);
    expect(mod.actions.single['total'], 1);
    expect(mod.room, 11);

    final record = rig.events.first;
    expect(record.source, EventSource.test);
    expect(record.actionText, 'Тест · Комната 12 → 11');
    expect(record.delivery, DeliveryStatus.delivered);
    await waitFor(() => rig.container.read(minecraftLinkProvider).parkour.room == 11,
        reason: 'программа знает новую комнату');
    await rig.close();
  });

  test('карточка без подарка проверяется в игре, но на эфир не срабатывает', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 40);
    final card = rig.container.read(parkourRulesProvider).rules.firstWhere((r) => r.actionId == 'to_last_level');
    final outcome = await rig.engine.test(card);
    expect(outcome.text, 'Тест · Комната 40 → 100');
    rig.tiktokGift('Роза', giftId: '5655');
    await Future<void>.delayed(const Duration(milliseconds: 200));
    expect(mod.actions, hasLength(1));
    await rig.close();
  });

  test('одна штука — одно срабатывание: «Роза ×5» по ходу серии даёт ровно 5', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 12);
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));

    for (var n = 1; n <= 5; n++) {
      rig.tiktokGift('Роза', count: n, comboId: 'c1', active: n < 5, giftId: '5655');
      await Future<void>.delayed(const Duration(milliseconds: 30));
    }
    await waitFor(() => rig.first?.actionState == ActionState.done && mod.executed == 5, reason: 'результат');
    // Повтор конца серии (как после переподключения) ничего не добавляет.
    rig.tiktokGift('Роза', count: 5, comboId: 'c1', active: false, giftId: '5655');
    rig.tiktokGift('Роза', count: 3, comboId: 'c1', active: false, giftId: '5655');
    await Future<void>.delayed(const Duration(milliseconds: 200));

    expect(mod.executed, 5);
    expect(mod.room, 7);
    expect(rig.first!.giftText, 'Роза ×5');
    expect(rig.first!.actionText, startsWith('Комната 12 → 7 (×5)'));
    expect(rig.first!.actionText, contains('принято 5, выполнено 5, в очереди 0'));
    // Нарастающее «всего» уходит в мод — мод берёт только прирост.
    expect(mod.actions.map((a) => a['total']).toSet().length, mod.actions.length);
    await rig.close();
  });

  test('серия ×1000 без лимита: 1000 срабатываний, прогресс «Выполнено … из 1 000»', () async {
    final rig = await Rig.start(timeout: const Duration(seconds: 3));
    final mod = await rig.connectMod(room: 50);
    mod.sendProgress = true;
    await rig.rules.upsert(rig.rule('Роза', 'push', giftId: '5655'));
    final seen = <String>{};
    for (final n in [1, 2, 3, 10, 100, 500, 999, 1000]) {
      rig.tiktokGift('Роза', count: n, comboId: 'big', active: n < 1000, giftId: '5655');
      await Future<void>.delayed(const Duration(milliseconds: 20));
      final text = rig.first?.actionText;
      if (text != null) seen.add(text);
    }
    await waitFor(() => rig.first?.actionState == ActionState.done, reason: 'итог серии');
    expect(mod.executed, 1000);
    expect(rig.first!.actionText, contains('принято 1\u00A0000, выполнено 1\u00A0000, в очереди 0'));
    expect(seen.any((t) => t.contains('Выполнено') || t.contains('принято')), isTrue, reason: '$seen');
    await rig.close();
  });

  test('тестовая серия ×1000: принято 1 000, повтор ничего не добавляет', () async {
    final rig = await Rig.start(timeout: const Duration(seconds: 3));
    final mod = await rig.connectMod(room: 30);
    final card = rig.rule('Роза', 'push');
    final recordId = await rig.engine.testSeries(card, units: 1000, pace: const Duration(milliseconds: 5));
    expect(recordId, isNotNull);
    await waitFor(() => rig.container.read(eventLogProvider).byId(recordId!)?.actionState == ActionState.done,
        reason: 'итог тестовой серии');
    await Future<void>.delayed(const Duration(milliseconds: 200));
    final record = rig.container.read(eventLogProvider).byId(recordId!)!;
    expect(record.source, EventSource.test);
    expect(record.count, 1000);
    expect(mod.executed, 1000, reason: 'повтор шага и повтор «всего» не добавили срабатываний');
    expect(record.actionText, contains('принято 1\u00A0000, выполнено 1\u00A0000, в очереди 0'));
    await rig.close();
  });

  test('два независимых подарка — два действия; ID подарка важнее названия', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 30);
    await rig.rules.upsert(rig.rule('Роза', 'room_forward', giftId: '5655'));
    rig.tiktokGift('Роза', giftId: '5655');
    rig.tiktokGift('Роза', giftId: '5655', viewer: 'Bob');
    rig.tiktokGift('Роза', giftId: '9999'); // другой подарок с тем же названием
    await waitFor(() => mod.executed == 2, reason: 'два действия');
    await Future<void>.delayed(const Duration(milliseconds: 150));
    expect(mod.executed, 2);
    expect(mod.room, 32);
    await rig.close();
  });

  test('без мира и без мода действие не выполняется, причина видна', () async {
    final rig = await Rig.start();
    final outcome = await rig.engine.test(rig.rule('Роза', 'room_back'));
    expect(outcome.ok, isFalse);
    expect(outcome.text, contains('не подключён'));
    expect(rig.events, isEmpty);

    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    rig.tiktokGift('Роза');
    await waitFor(() => rig.first?.actionState == ActionState.skipped, reason: 'пропуск');
    expect(rig.first!.actionText, contains('не подключён'));
    await rig.close();
  });

  test('режим выключен — правила не срабатывают', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod();
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    await rig.rules.setModeActive(false);
    rig.tiktokGift('Роза');
    await Future<void>.delayed(const Duration(milliseconds: 200));
    expect(mod.actions, isEmpty);
    expect(rig.first!.actionText, isNull);
    await rig.close();
  });

  test('«Второй шанс от чата» отменяет помеху во время отсчёта', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 20);
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    await rig.rules.upsert(rig.rule('Сердце', 'second_chance', params: {'seconds': 2}));

    rig.tiktokGift('Роза', viewer: 'Troll');
    await waitFor(() => mod.countdowns.isNotEmpty, reason: 'отсчёт в игре');
    expect(mod.countdowns.first['seconds'], 2);
    rig.tiktokGift('Сердце', viewer: 'Helper');
    await waitFor(() => mod.countdowns.length == 2, reason: 'отмена отсчёта');
    await Future<void>.delayed(const Duration(milliseconds: 2300));

    expect(mod.actions, isEmpty, reason: 'помеха отменена');
    expect(mod.room, 20);
    final rose = rig.events.firstWhere((e) => e.giftName == 'Роза');
    final heart = rig.events.firstWhere((e) => e.giftName == 'Сердце');
    expect(rose.actionState, ActionState.skipped);
    expect(rose.actionText, contains('Helper'));
    expect(heart.actionText, contains('Отменил «Комната назад»'));
    await rig.close();
  });

  test('без «Второго шанса» помеха срабатывает после отсчёта', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod(room: 20);
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    await rig.rules.upsert(rig.rule('Сердце', 'second_chance', params: {'seconds': 1}));
    rig.tiktokGift('Роза');
    await waitFor(() => mod.executed == 1, reason: 'выполнено после отсчёта');
    expect(mod.room, 19);
    await rig.close();
  });

  test('СУПЕР СИЛЬНЫЙ ТОЛЧОК: параметры уходят в мод, результат в истории', () async {
    final rig = await Rig.start();
    final mod = await rig.connectMod();
    final outcome = await rig.engine.test(rig.rule('Лев', 'super_push', params: {'direction': 'right'}));
    expect(outcome.text, 'Тест · Суперсильный толчок вправо');
    final params = (mod.actions.single['params'] as Map).cast<String, Object?>();
    expect(params, {'direction': 'right', 'strength': 3.0, 'lift': 0.8});
    await rig.close();
  });

  test('переход в комнату и мод без ответа', () async {
    final rig = await Rig.start(timeout: const Duration(milliseconds: 300));
    final mod = await rig.connectMod(room: 5);
    final go = await rig.engine.goToRoom(12);
    expect(go.ok, isTrue);
    expect(go.text, 'Комната 5 → 12');
    mod.respondToActions = false;
    final outcome = await rig.engine.test(rig.rule('Роза', 'room_back'));
    expect(outcome.ok, isFalse);
    expect(outcome.text, contains('не ответила'));
    expect(rig.events.first.delivery, DeliveryStatus.unconfirmed);
    await rig.close();
  });

  test('карточки сохраняются и читаются после перезапуска; старые поля серии не мешают', () async {
    final store = MemoryJsonStore();
    store.files[ParkourRulesRepository.fileName] =
        '{"version":1,"modeActive":true,"rules":[{"id":"old","giftName":"Роза","giftId":"5655",'
        '"actionId":"push","params":{"direction":"back","strength":2.5},"seriesMode":"once","limit":5,"enabled":true}]}';
    var rig = await Rig.start(store: store);
    var state = rig.container.read(parkourRulesProvider);
    expect(state.rules.single.bindingText, 'Роза → Толчок');
    expect(state.rules.single.params, {'direction': 'back', 'strength': 2.5});
    await rig.rules.setModeActive(false);
    await rig.close();

    rig = await Rig.start(store: store);
    state = rig.container.read(parkourRulesProvider);
    expect(state.modeActive, isFalse);
    expect(state.rules.single.giftId, '5655');
    await rig.close();
  });

  test('каталог: три набора совпали — «Все подарки … доступны»; ID подставляются в карточки', () async {
    final rig = await Rig.start();
    await rig.container.read(settingsProvider.notifier).saveNickname('@dirron');
    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    rig.fetcher.gifts = const [
      CatalogGift(id: '5655', name: 'Rose', diamonds: 1, imageUrl: 'https://example.test/rose.png'),
      CatalogGift(id: '5487', name: 'Finger Heart', diamonds: 5),
      CatalogGift(id: '5655', name: 'Rose', diamonds: 1),
    ];
    final report = await rig.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    expect(report.fetched, isTrue);
    expect(report.connectorCount, 2);
    expect(report.savedCount, 2);
    expect(report.editorCount, 2);
    expect(report.allAvailable, isTrue);
    expect(rig.store.files.containsKey(GiftCatalogRepository.fileName), isTrue);
    final rose = rig.container.read(parkourRulesProvider).rules.firstWhere((r) => r.giftName == 'Роза');
    expect(rose.giftId, '5655');

    // Привязка работает после обновления каталога.
    final mod = await rig.connectMod(room: 12);
    rig.tiktokGift('Роза', giftId: '5655', key: 'msg:1');
    await waitFor(() => mod.executed == 1, reason: 'действие по ID');

    // Подарок не из каталога во время эфира — пометка в истории.
    rig.tiktokGift('Мистика', giftId: '424242', key: 'msg:2');
    await waitFor(() => rig.first?.unknownGift ?? false, reason: 'пометка');
    expect(rig.first!.actionText, contains('обновите каталог'));

    // Ошибка сети: открыт последний успешный каталог, «все доступны» не пишется.
    rig.fetcher.error = const CatalogFetchException('network', 'Ошибка сети: ENOTFOUND');
    final failed = await rig.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    expect(failed.allAvailable, isFalse);
    expect(failed.error, contains('ENOTFOUND'));
    expect(rig.container.read(giftCatalogProvider).catalog.gifts, hasLength(2));
    await rig.close();
  });

  test('без ника и без эфира скачивается полный список; полученные в эфире подарки тоже доступны', () async {
    final rig = await Rig.start();
    rig.fetcher.error = const CatalogFetchException('network', 'Ошибка сети: ENOTFOUND');
    final report = await rig.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    expect(report.allAvailable, isFalse);
    expect(rig.fetcher.calls, 1, reason: 'ник не нужен');
    expect(rig.fetcher.lastUniqueId, isNull);

    await rig.rules.upsert(rig.rule('Роза', 'room_back'));
    rig.container.read(eventBusProvider).publish(GiftEvent(
          id: generateEventId(),
          createdAt: DateTime.now(),
          source: EventSource.tiktok,
          viewerName: 'Alex',
          giftName: 'Роза',
          giftId: '5655',
          giftImage: 'https://example.test/rose.png',
          diamonds: 1,
          count: 1,
          sourceKey: 'msg:seen',
        ));
    await waitFor(() => rig.container.read(giftCatalogProvider).catalog.onlySeen, reason: 'подарок запомнен');
    final catalog = rig.container.read(giftCatalogProvider).catalog;
    expect(catalog.selectable.single.imageUrl, 'https://example.test/rose.png');

    // Сеть появилась: полный список TikTok без эфира и без ника.
    rig.fetcher.error = null;
    rig.fetcher.gifts = const [
      CatalogGift(id: '9427', name: 'Пегас', diamonds: 42999),
      CatalogGift(id: '5655', name: 'Роза', diamonds: 1, imageUrl: 'https://example.test/rose.png'),
      CatalogGift(id: '5487', name: 'Сердечко', diamonds: 5),
    ];
    final full = await rig.container.read(giftCatalogProvider.notifier).refreshAndCheck();
    expect(full.fetched, isTrue);
    expect(full.allAvailable, isTrue);
    final after = rig.container.read(giftCatalogProvider).catalog;
    expect(after.gifts.map((g) => g.name), ['Роза', 'Сердечко', 'Пегас'], reason: 'по цене');
    expect(after.onlySeen, isFalse);
    await rig.close();
  });

  test('список из установщика виден сразу, при запуске обновляется; свежий — не трогается', () async {
    const snapshot = GiftCatalog(gifts: [
      CatalogGift(id: '5655', name: 'Роза', diamonds: 1),
      CatalogGift(id: '9427', name: 'Пегас', diamonds: 42999),
    ]);
    final rig = await Rig.start(snapshot: snapshot);
    expect(rig.container.read(giftCatalogProvider).catalog.gifts, hasLength(2), reason: 'сразу после установки');
    rig.fetcher.gifts = const [
      CatalogGift(id: '5655', name: 'Роза', diamonds: 1),
      CatalogGift(id: '9427', name: 'Пегас', diamonds: 42999),
      CatalogGift(id: '1444186', name: 'Музыкант FEST', diamonds: 1599),
    ];
    await rig.container.read(giftCatalogProvider.notifier).autoSync();
    expect(rig.fetcher.calls, 1, reason: 'список из установщика обновляется при запуске');
    expect(rig.container.read(giftCatalogProvider).catalog.gifts, hasLength(3));
    await rig.container.read(giftCatalogProvider.notifier).autoSync();
    expect(rig.fetcher.calls, 1, reason: 'свежий список не скачивается снова');
    await rig.close();
  });

  test('ответ коннектора --fetch-gifts разбирается', () {
    final gifts = NodeGiftCatalogFetcher.parseFetchOutput(
        '{"type":"gifts","gifts":[{"id":"5655","name":"Rose","diamonds":1,"image":"https://x/r.png"},'
        '{"id":"0","name":"Bad"}]}\n');
    expect(gifts.map((g) => g.id), ['5655']);
    expect(gifts.single.displayName, 'Роза');
    expect(
      () => NodeGiftCatalogFetcher.parseFetchOutput(
          '{"type":"status","status":"offline","kind":"offline","message":"Эфир не найден"}'),
      throwsA(isA<CatalogFetchException>().having((e) => e.kind, 'kind', 'offline')),
    );
  });

  test('каталог действий: 24 действия, у каждого группа и подсказка', () {
    expect(parkourActions, hasLength(24));
    final ids = parkourActions.map((a) => a.id).toSet();
    expect(ids, hasLength(24));
    expect(parkourActionById('lightning')!.category, ActionCategory.hindrance);
    expect(parkourActionById('push')!.defaults()['direction'], 'random', reason: 'толчок в случайную сторону');
    expect(ids, containsAll(['push', 'to_last_level', 'to_first_level', 'super_push']));
    expect(parkourActionById('to_last_level')!.hint, 'Переносит на старт комнаты 100');
    expect(parkourActionById('super_push')!.category, ActionCategory.hindrance);
    expect(parkourActionById('to_first_level')!.category, ActionCategory.move);
    expect(parkourActionById('shield')!.category, ActionCategory.help);
    expect(parkourActionById('super_push')!.defaults(), {'direction': 'random', 'strength': 3.0, 'lift': 0.8});
  });

  test('карточки действий можно переставлять, порядок сохраняется', () async {
    final rig = await Rig.start();
    final a = rig.rule('Роза', 'push');
    final b = rig.rule('Лев', 'shield');
    final c = rig.rule('Сердце', 'freeze');
    for (final r in [a, b, c]) {
      await rig.rules.upsert(r);
    }
    final start = rig.container.read(parkourRulesProvider).rules.length;
    await rig.rules.move(c.id, 0);
    var ids = rig.container.read(parkourRulesProvider).rules.map((r) => r.id).toList();
    expect(ids.first, c.id);
    await rig.rules.move(c.id, 99);
    ids = rig.container.read(parkourRulesProvider).rules.map((r) => r.id).toList();
    expect(ids.last, c.id);
    expect(ids, hasLength(start));
    await rig.close();
  });

  test('переподписка: по умолчанию один зритель — один раз, с включённой — каждый раз', () async {
    final rig = await Rig.start();
    final once = rig.rule('Подписка', 'shield', giftId: followTriggerId);
    final again = rig.rule('Подписка', 'push', giftId: followTriggerId).copyWith(repeatFollow: true);
    await rig.rules.upsert(once);
    await rig.rules.upsert(again);
    final bus = rig.container.read(eventBusProvider);
    final got = <GiftEvent>[];
    final sub = bus.on<GiftEvent>().where((e) => isSocialTrigger(e.giftId)).listen(got.add);
    for (var i = 0; i < 3; i++) {
      bus.publish(FollowEvent(viewerId: 'alex', viewerName: 'Alex', source: EventSource.tiktok));
    }
    await Future<void>.delayed(const Duration(milliseconds: 50));
    expect(got.where((e) => once.matches(e)), hasLength(1));
    expect(got.where((e) => again.matches(e)), hasLength(3));
    expect(GiftRule.fromJson(again.toJson())!.repeatFollow, isTrue, reason: 'выбор сохраняется');
    await sub.cancel();
    await rig.close();
  });

  test('лайки и подписка запускают карточки: каждые 10 лайков — одно срабатывание', () async {
    final rig = await Rig.start();
    final likes = rig.rule('Лайки', 'push', giftId: likesTriggerId);
    await rig.rules.upsert(likes);
    final likes25 = rig.rule('Лайки', 'freeze', giftId: likesTriggerId).copyWith(likesEvery: 25);
    await rig.rules.upsert(likes25);
    await rig.rules.upsert(rig.rule('Подписка', 'shield', giftId: followTriggerId));
    final bus = rig.container.read(eventBusProvider);
    final social = <GiftEvent>[];
    final sub = bus.on<GiftEvent>().where((e) => isSocialTrigger(e.giftId)).listen(social.add);
    bus
      ..publish(LikeEvent(viewerId: 'mira', viewerName: 'Mira', likes: 15, source: EventSource.tiktok, sourceKey: 'l1'))
      ..publish(LikeEvent(viewerId: 'mira', viewerName: 'Mira', likes: 10, source: EventSource.tiktok, sourceKey: 'l2'))
      ..publish(FollowEvent(viewerId: 'alex', viewerName: 'Alex', source: EventSource.tiktok))
      // Отписался и подписался снова — по умолчанию не засчитывается.
      ..publish(FollowEvent(viewerId: 'alex', viewerName: 'Alex', source: EventSource.tiktok));
    await Future<void>.delayed(const Duration(milliseconds: 50));
    expect(social.where((e) => e.giftId == '$likesTriggerId:${likes.id}').map((e) => e.count), [1, 1],
        reason: 'по 10: 25 лайков → 2 раза');
    expect(social.where((e) => e.giftId == '$likesTriggerId:${likes25.id}').map((e) => e.count), [1],
        reason: 'по 25: 25 лайков → 1 раз');
    expect(likes.matches(social.first), isTrue);
    expect(likes25.matches(social.first), isFalse, reason: 'у каждой карточки свой счёт');
    final saved = GiftRule.fromJson(likes25.toJson())!;
    expect(saved.likesEvery, 25, reason: 'порог сохраняется');
    final follows = social.where((e) => e.giftId?.startsWith(followTriggerId) ?? false).toList();
    expect(follows.single.viewerName, 'Alex', reason: 'переподписка не засчитана');
    await sub.cancel();
    await rig.close();
  });

  test('у каждого действия есть картинка (и общая запасная) и она объявлена в pubspec', () {
    for (final action in parkourActions) {
      expect(File('assets/actions/${action.id}.png').existsSync(), isTrue, reason: action.id);
    }
    expect(File('assets/actions/fallback.png').existsSync(), isTrue);
    expect(File('pubspec.yaml').readAsStringSync(), contains('assets/actions/'));
  });

  test('формат чисел: «1 000»', () {
    expect(formatCount(1000), '1\u00A0000');
    expect(formatCount(237), '237');
    expect(formatCount(1234567), '1\u00A0234\u00A0567');
  });
}
